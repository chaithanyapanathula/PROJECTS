package com.example.miniproject;


    import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

    public class ExpandableListDataItems {
        public static HashMap<String, List<String>> getData() {
            HashMap<String, List<String>> expandableDetailList = new HashMap<String, List<String>>();


            List<String> f1 = new ArrayList<String>();
            f1.add("The often stated general rule of thumb (don't stock your tank using this rule!) is 1 inch of fish per gallon of water. Remember to use the future adult size of your fish when computing the total inches of fish you can have. This rule is pretty silly if you think about it though. Do you think a 20 inch fish would be comfortable in a 20 gallon tank? A better rule would be 1 inch of fish per 2 or 3 gallons of water. Avoid the temptation to overcrowd your tank. If you do overcrowd the tank you will need to perform maintenance more often and you risk the health of the fish you are keeping!");


            List<String> f2 = new ArrayList<String>();
            f2.add("Maybe - first test for chlorine and/or chloramine. Most likely you will have these chemicals in your water and you will need to remove or neutralize them before adding water to your tank.");


            List<String> f3 = new ArrayList<String>();
            f3.add("It depends on how many fish you have and the quality of your filtration system. In lightly stocked tanks, I would recommend changing 10 percent of the water once a week. You could probably get by with vacuuming the gravel once every two weeks depending on the population of your tank. Heavier stocked tanks will need larger (25% or more) weekly water changes and gravel vaccuming.");
            List<String> f4 = new ArrayList<String>();
            f4.add("The aquarium water temperature depends on the fish species in question. Different species require different temperatures. Generally speaking, for tropical fish a good temperature range would be anywhere from 72 °F to 78 °F (22 °C to 26 °C);. Research the fish you're interested in keeping before buying since some have different temperature requirements.");
            List<String> f5 = new ArrayList<String>();
            f5.add("Your fish need some down time just like you do. Sure, they don't crawl under the covers and go to sleep, but they do hunker down in a quite place and rest at night. They need this period without lights. A good photoperiod (time the lights are on) is around 10 hours per day. ");


            expandableDetailList.put("How many tropical fish can I have?", f1);
            expandableDetailList.put("Can I use tap water to fill my tank?", f2);
            expandableDetailList.put("How often should I change the water?", f3);
            expandableDetailList.put("What should the fish tank temperature be set at?", f4);
            expandableDetailList.put("Can I leave my aquarium lights on 24 hours?", f5);
            return expandableDetailList;
        }
    }

