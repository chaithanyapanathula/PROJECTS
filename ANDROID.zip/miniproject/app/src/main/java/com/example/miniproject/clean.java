package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

public class clean extends AppCompatActivity {
    private TextView ct,cd;
    private ImageView ci;
    private DrawerLayout drawerLayout3;
    private ActionBarDrawerToggle actionBarDrawerToggle3;

    private String phone,name,emailid,password;
    private NavigationView nav3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean);
        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");
        drawerLayout3 = findViewById(R.id.my_drawer_layout3);

        nav3=(NavigationView)findViewById(R.id.nav3);
        actionBarDrawerToggle3 = new ActionBarDrawerToggle(this, drawerLayout3, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout3.addDrawerListener(actionBarDrawerToggle3);
        actionBarDrawerToggle3.syncState();

        nav3.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(clean.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(clean.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(clean.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(clean.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(clean.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(clean.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(clean.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(clean.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(clean.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout3.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ct=(TextView) findViewById(R.id.ct);
        cd=(TextView) findViewById(R.id.cd);
        ci=(ImageView)findViewById(R.id.ci);
        DBClean DB = new DBClean(getApplicationContext());
        ci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int cnt = DB.getcountdata(phone);
                if(cnt>0){
                    DB.updateuserdata(phone);
                }
                else{
                    DB.insertuserdata(phone);

                }


                cd.setText("LAST ACTIVITY:JUST NOW");
                ci.setImageResource(R.drawable.done);

            }
        });
cd.setText(DB.usergetDate(phone));

}
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle3.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }
}