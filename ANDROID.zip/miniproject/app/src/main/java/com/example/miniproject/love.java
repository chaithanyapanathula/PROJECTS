package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

import com.google.android.material.navigation.NavigationView;

public class love extends AppCompatActivity {
    private DrawerLayout drawerLayout6;
    private ActionBarDrawerToggle actionBarDrawerToggle6;
    Spinner s11;
    Button b11;
    TextView t11;
    ImageView iv11;

    private String phone,name,emailid,password;
    private NavigationView nav6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_love);
        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");
        drawerLayout6= findViewById(R.id.my_drawer_layout6);

        nav6=(NavigationView)findViewById(R.id.nav6);
        actionBarDrawerToggle6 = new ActionBarDrawerToggle(this, drawerLayout6, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout6.addDrawerListener(actionBarDrawerToggle6);
        actionBarDrawerToggle6.syncState();

        nav6.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(love.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(love.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(love.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(love.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(love.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(love.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(love.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(love.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(love.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout6.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        s11=(Spinner)findViewById(R.id.s1);
        b11=(Button)findViewById(R.id.b1);
        t11=(TextView) findViewById(R.id.t1);
        iv11=(ImageView) findViewById(R.id.iv1);


        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int x = s11.getSelectedItemPosition();
                if (x==1) {
                    t11.setText("FOOD \n 1.Lamb meal \n 2.chicken meal \n 3.sweeet potatoes \n 4.peas" );
                    iv11.setImageResource(R.drawable.boxer);
                }
                if(x==2){
                    t11.setText("FOOD \n 1.Fishes \n 2.Vegetables \n 3.Fruits \n 4.Eggs etc" );
                    iv11.setImageResource(R.drawable.poodle);

                }
                if(x==3) {
                    t11.setText("FOOD \n 1.Fishes \n 2.chicken  \n 3.Fruits \n 4.pork etc");
                    iv11.setImageResource(R.drawable.shepeard);
                }
                if(x==4) {
                    t11.setText("FOOD \n 1.Banana \n 2.Vegetables \n 3.chicken \n 4.Dog food roll etc");
                    iv11.setImageResource(R.drawable.doberman);
                }
                if(x==5) {
                    t11.setText("FOOD \n 1.Diary foods \n 2.Duck  \n 3.Tuna \n 4.Fruits and vegetables etc");
                    iv11.setImageResource(R.drawable.lab);
                }
                if(x==6) {
                    t11.setText("FOOD \n 1.Bones \n 2.Vegetables \n 3. Real meat\n 4.Dog royal etc \n 5.pedigree");
                    iv11.setImageResource(R.drawable.beag);
                }
                if(x==7) {
                    t11.setText("FOOD \n 1.pedigree \n 2.Adult dry food \n 3.chicken \n 4.bones");
                    iv11.setImageResource(R.drawable.dalmatin);
                }
                if(x==8) {
                    t11.setText("best food we will update soon");
                    iv11.setImageResource(R.drawable.best);

                }

            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle6.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }
}