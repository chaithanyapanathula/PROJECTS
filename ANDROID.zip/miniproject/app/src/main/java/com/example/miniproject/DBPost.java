package com.example.miniproject;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBPost extends SQLiteOpenHelper {
    public DBPost(Context context) {
        super(context, "Userpostdata.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userpost(postid INTEGER PRIMARY KEY  AUTOINCREMENT,phno TEXT,name TEXT,postimg TEXT,posttitle TEXT,postdec TEXT,postdate date default CURRENT_DATE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Userpost");
    }
    public Boolean insertpostdata(String name, String phno, String postimg,String posttitle,String postdec)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("phno", phno);
        contentValues.put("name", name);
        contentValues.put("postimg", postimg);
        contentValues.put("posttitle",posttitle);
        contentValues.put("postdec",postdec);
        long result=DB.insert("Userpost", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Cursor getblogs ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userpost",null);
        return cursor;

    }

}