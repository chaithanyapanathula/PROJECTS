package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.VideoView;

import android .widget.*;
public class nxtlogin extends AppCompatActivity {
    private VideoView videoBG;
    private View a1;
    MediaPlayer mMediaPlayer;
    int mCurrentVideoPosition;
    EditText em,pswd;
    Button regd,nxtregd,nxtreg2d;
    String ph,nm,eid,pd;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nxtlogin);
        a1=(View)findViewById(R.id.a1);
        // Hook up the VideoView to our UI.
        regd = (Button) findViewById(R.id.reg3);
        nxtregd = (Button) findViewById(R.id.nxtreg3);
        nxtreg2d= (Button) findViewById(R.id.fwp);
        em=(EditText)findViewById(R.id.em3);
        pswd=(EditText)findViewById(R.id.pswd3);
        nxtregd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), login.class);
                view.getContext().startActivity(intent);}
        });
        nxtreg2d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), forgotpw.class);
                view.getContext().startActivity(intent);}
        });
        regd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLogin DB = new DBLogin(getApplicationContext());


                // below line is to get data from all edit text fields.String name1 = phno.getText().toString();

                String em1 = em.getText().toString();
                String pswd1 =pswd.getText().toString();
                if ( em1.isEmpty() || pswd1.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean checkdata = DB.checkuserdata(em1,pswd1);
                if(checkdata==true){
                    Toast.makeText(getApplicationContext(), "Entry validated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(view.getContext(), dash.class);
                    Cursor res=DB.getuserdata(em1,pswd1);
                    while(res.moveToNext()){
                        ph=res.getString(0);
                        nm=res.getString(1);
                        eid=res.getString(2);
                        pd=res.getString(3);
                    }
                    intent.putExtra("phone",ph);
                    intent.putExtra("name",nm);
                    intent.putExtra("emailid",eid);
                    intent.putExtra("password",pd);
                    view.getContext().startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Invalid Credantials", Toast.LENGTH_SHORT).show();
                    em.setText("");
                    pswd.setText("");

                }
                }
        });
        videoBG = (VideoView) findViewById(R.id.videoView);

        // Build your video Uri
        Uri uri = Uri.parse("android.resource://" // First start with this,
                + getPackageName() // then retrieve your package name,
                + "/" // add a slash,
                + R.raw.bkg); // and then finally add your video resource. Make sure it is stored
        // in the raw folder.

        // Set the new Uri to our VideoView
        videoBG.setVideoURI(uri);
        // Start the VideoView
        videoBG.start();

        // Set an OnPreparedListener for our VideoView. For more information about VideoViews,
        // check out the Android Docs: https://developer.android.com/reference/android/widget/VideoView.html
        videoBG.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mMediaPlayer = mediaPlayer;

                // We want our video to play over and over so we set looping to true.
                mMediaPlayer.setLooping(true);
                // We then seek to the current posistion if it has been set and play the video.
                if (mCurrentVideoPosition != 0) {
                    mMediaPlayer.seekTo(mCurrentVideoPosition);
                    mMediaPlayer.start();
                }
            }
        });
    }

    /*================================ Important Section! ================================
    We must override onPause(), onResume(), and onDestroy() to properly handle our
    VideoView.
     */

    @Override
    protected void onPause() {
        super.onPause();
        // Capture the current video position and pause the video.
        int mCurrentVideoPosition = mMediaPlayer.getCurrentPosition();
        videoBG.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restart the video when resuming the Activity
        videoBG.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // When the Activity is destroyed, release our MediaPlayer and set it to null.
        mMediaPlayer.release();
        mMediaPlayer = null;
    }


}