package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.VideoView;

import android .widget.*;
public class login extends AppCompatActivity {
    private VideoView videoBG;
    private View a1;
    MediaPlayer mMediaPlayer;
    int mCurrentVideoPosition;
    EditText name,phno,em,pswd;

    Button reg,nxtreg;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        a1=(View)findViewById(R.id.a1);
        name=(EditText)findViewById(R.id.name);
        phno=(EditText)findViewById(R.id.phno);
        em=(EditText)findViewById(R.id.em);
        pswd=(EditText)findViewById(R.id.pswd);
        // Hook up the VideoView to our UI.
        reg = (Button) findViewById(R.id.reg);
        nxtreg = (Button) findViewById(R.id.nxtreg);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLogin DB = new DBLogin(getApplicationContext());


                        // below line is to get data from all edit text fields.
                String name1 = phno.getText().toString().trim();
                        String phno1 = name.getText().toString().trim();
                        String em1 = em.getText().toString().trim();
                        String pswd1 =pswd.getText().toString().trim();
                if (name1.equals("") || phno1.equals("") || em1.equals("") || pswd1.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(pswd1.length()<5){
                    Toast.makeText(getApplicationContext(), "Password must be more than 5 characters.", Toast.LENGTH_SHORT).show();
                    return;
                }
else{

                Boolean checkinsertdata = DB.insertuserdata(name1,phno1,em1,pswd1);
                if(checkinsertdata==true) {
                    Toast.makeText(getApplicationContext(), "New Entry Inserted", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(view.getContext(), nxtlogin.class);
                    view.getContext().startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
                }}


            }}
        );
        nxtreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), nxtlogin.class);
                view.getContext().startActivity(intent);}
        });
        videoBG = (VideoView) findViewById(R.id.videoView);

        // Build your video Uri
        Uri uri = Uri.parse("android.resource://" // First start with this,
                + getPackageName() // then retrieve your package name,
                + "/" // add a slash,
                + R.raw.bkg); // and then finally add your video resource. Make sure it is stored
        // in the raw folder.

        // Set the new Uri to our VideoView
        videoBG.setVideoURI(uri);
        // Start the VideoView
        videoBG.start();

        // Set an OnPreparedListener for our VideoView. For more information about VideoViews,
        // check out the Android Docs: https://developer.android.com/reference/android/widget/VideoView.html
        videoBG.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mMediaPlayer = mediaPlayer;

                // We want our video to play over and over so we set looping to true.
                mMediaPlayer.setLooping(true);
                // We then seek to the current posistion if it has been set and play the video.
                if (mCurrentVideoPosition != 0) {
                    mMediaPlayer.seekTo(mCurrentVideoPosition);
                    mMediaPlayer.start();
                }
            }
        });
    }

    /*================================ Important Section! ================================
    We must override onPause(), onResume(), and onDestroy() to properly handle our
    VideoView.
     */

    @Override
    protected void onPause() {
        super.onPause();
        // Capture the current video position and pause the video.
        int mCurrentVideoPosition = mMediaPlayer.getCurrentPosition();
        videoBG.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restart the video when resuming the Activity
        videoBG.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // When the Activity is destroyed, release our MediaPlayer and set it to null.
        mMediaPlayer.release();
        mMediaPlayer = null;
    }


}