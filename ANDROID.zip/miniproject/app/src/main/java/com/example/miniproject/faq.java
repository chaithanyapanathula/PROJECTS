package com.example.miniproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class faq extends AppCompatActivity {
    private DrawerLayout drawerLayout4;
    private ActionBarDrawerToggle actionBarDrawerToggle4;

    private String phone,name,emailid,password;
    private NavigationView nav4;
    ExpandableListView expandableListViewExample;
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableTitleList;
    HashMap<String, List<String>> expandableDetailList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");
        drawerLayout4 = findViewById(R.id.my_drawer_layout4);

        nav4=(NavigationView)findViewById(R.id.nav4);
        actionBarDrawerToggle4= new ActionBarDrawerToggle(this, drawerLayout4, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout4.addDrawerListener(actionBarDrawerToggle4);
        actionBarDrawerToggle4.syncState();

        nav4.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(faq.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(faq.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(faq.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(faq.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(faq.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(faq.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(faq.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(faq.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(faq.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout4.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        expandableListViewExample = (ExpandableListView) findViewById(R.id.expandableListViewSample);
        expandableDetailList = ExpandableListDataItems.getData();
        expandableTitleList = new ArrayList<String>(expandableDetailList.keySet());
        expandableListAdapter = new CustomizedExpandableListAdapter(this, expandableTitleList, expandableDetailList);
        expandableListViewExample.setAdapter(expandableListAdapter);

        // This method is called when the group is expanded
        expandableListViewExample.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(), expandableTitleList.get(groupPosition) + " List Expanded.", Toast.LENGTH_SHORT).show();
            }
        });

        // This method is called when the group is collapsed
        expandableListViewExample.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(), expandableTitleList.get(groupPosition) + " List Collapsed.", Toast.LENGTH_SHORT).show();
            }
        });

        // This method is called when the child in any group is clicked
        // via a toast method, it is shown to display the selected child item as a sample
        // we may need to add further steps according to the requirements
        expandableListViewExample.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                Toast.makeText(getApplicationContext(), expandableTitleList.get(groupPosition)
                        + " -> "
                        + expandableDetailList.get(
                        expandableTitleList.get(groupPosition)).get(
                        childPosition), Toast.LENGTH_SHORT
                ).show();
                return false;
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle4.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }
}