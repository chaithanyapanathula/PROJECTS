package com.example.miniproject;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class blogadd extends AppCompatActivity {
    ActivityResultLauncher<String> mGetContent;
    Button postbtn;
    EditText title,desc;
    ImageView postim;
    Uri selectedImageUri=null;
    String d="";
    String t="";
    String im="";


    private DrawerLayout drawerLayout1;
    private ActionBarDrawerToggle actionBarDrawerToggle1;

    private String phone,name,emailid,password;
    private NavigationView nav1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blogadd);
        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");


        drawerLayout1 = findViewById(R.id.my_drawer_layout1);

        nav1=(NavigationView)findViewById(R.id.nav1);
        actionBarDrawerToggle1 = new ActionBarDrawerToggle(this, drawerLayout1, R.string.nav_open, R.string.nav_close);


        drawerLayout1.addDrawerListener(actionBarDrawerToggle1);
        actionBarDrawerToggle1.syncState();
        nav1.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {

                            Intent intent;
                            switch (menuItem.getItemId()) {
                                case R.id.nav_about:
                                    intent=new Intent(blogadd.this, about.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);


                                    break;
                                case R.id.nav_addpost:
                                    intent=new Intent(blogadd.this, blogadd.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_home:
                                    intent=new Intent(blogadd.this, dash.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_love:
                                    intent=new Intent(blogadd.this,love.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_food:
                                    intent=new Intent(blogadd.this, reminder.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_clean:
                                    intent=new Intent(blogadd.this, clean.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_shop:
                                    intent=new Intent(blogadd.this, shop.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_faqs:
                                    intent=new Intent(blogadd.this, faq.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;
                                case R.id.nav_logout:
                                    intent=new Intent(blogadd.this,use.class);
                                    intent.putExtra("phone",phone);
                                    intent.putExtra("name",name);
                                    intent.putExtra("emailid",emailid);
                                    intent.putExtra("password",password);
                                    startActivity(intent);
                                    break;



                                default:
                                    break;
                        }

                        menuItem.setChecked(true);
                        drawerLayout1.closeDrawers();
                        return true;
                    }
                });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        postbtn=(Button)findViewById(R.id.postbtn);
        title=(EditText) findViewById(R.id.posttitle);
        desc=(EditText) findViewById(R.id.postdescription);
        postim=(ImageView) findViewById(R.id.postimg);


      mGetContent=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri result) {
                selectedImageUri=result;
                postim.setImageURI(result);
                im=result.toString();
            }});
        postim.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mGetContent.launch("image/*");

            }
        });
        postbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t=title.getText().toString().trim();
                d=desc.getText().toString().trim();
                if(t.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Title",Toast.LENGTH_SHORT).show();
                }
                else if(d.isEmpty() || im.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Title",Toast.LENGTH_SHORT).show();
                }
                else{
                    DBPost DB = new DBPost(getApplicationContext());

                    Boolean checkpostdata = DB.insertpostdata(name,phone,im,t,d);
                    if(checkpostdata==true) {
                        Toast.makeText(getApplicationContext(), "Post added", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(view.getContext(), dash.class);
                        intent.putExtra("phone",phone);
                        intent.putExtra("name",name);
                        intent.putExtra("emailid",emailid);
                        intent.putExtra("password",password);
                        view.getContext().startActivity(intent);
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Retry", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle1.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }

}