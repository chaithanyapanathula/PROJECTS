package com.example.miniproject;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.TooltipCompat;


import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.*;
import android.widget.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.io.File;



public class dash extends AppCompatActivity  {
    ActivityResultLauncher<String> mGetContent1;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    //ImageButton diet,home,shop,advice;
    //MenuItem user;
    private String phone,name,emailid,password;
    private int p1;
    private String p2;
    private String p3;
    private String p4;
    private String p5;
    private String p6,p7;
    ImageButton pnext;
    TextView pt,pd,pn,pdt;
    ImageView pi;
    private NavigationView nav;
    Handler mainHandler = new Handler();
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash);
        pnext=(ImageButton)findViewById(R.id.pnext);
        pt=(TextView)findViewById(R.id.pt);
        pd=(TextView)findViewById(R.id.pd);
        pdt=(TextView)findViewById(R.id.pdt);
        pi=(ImageView)findViewById(R.id.pi);
        pn=(TextView) findViewById(R.id.pn);

        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");


        drawerLayout = findViewById(R.id.my_drawer_layout);

        nav=(NavigationView)findViewById(R.id.nav);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        mGetContent1=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri result) {

                pi.setImageURI(result);

            }});
        nav.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(dash.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(dash.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(dash.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(dash.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(dash.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(dash.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(dash.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(dash.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(dash.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        DBPost DB = new DBPost(getApplicationContext());
        Cursor res=DB.getblogs();
      if (res.moveToNext()) {
            p1 = res.getInt(0);
            p2 = res.getString(1);
            p3 = res.getString(2);
            p4 = res.getString(3);
            p5 = res.getString(4);
            p6 = res.getString(5);
            p7=res.getString(6);

            pn.setText(p2);
            pt.setText(p5);
            pd.setText(p6);
            pdt.setText(p7);
            if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages.jpg")){
                pi.setImageResource(R.drawable.im1);
            }
            else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(2).jpg")){
                pi.setImageResource(R.drawable.im3);
            }
            else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                pi.setImageResource(R.drawable.im2);
            }
            else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                pi.setImageResource(R.drawable.im4);
            }
        //  String url =p4;
        //  new FetchImage(url).start();



            }
       pnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (res.moveToNext()) {
                    p1 = res.getInt(0);
                    p2 = res.getString(1);
                    p3 = res.getString(2);
                    p4 = res.getString(3);
                    p5 = res.getString(4);
                    p6 = res.getString(5);

                    pn.setText(p2);
                    pt.setText(p5);
                    pd.setText(p6);
                    pdt.setText(p7);
                    if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages.jpg")){
                        pi.setImageResource(R.drawable.im1);
                    }
                    else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(2).jpg")){
                        pi.setImageResource(R.drawable.im3);
                    }
                    else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                        pi.setImageResource(R.drawable.im2);
                    }
                    else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                        pi.setImageResource(R.drawable.im4);
                    }


                   // String url =p4;
                   // new FetchImage(url).start();
                }
                else{
                   if(res.moveToFirst()){
                       p1 = res.getInt(0);
                       p2 = res.getString(1);
                       p3 = res.getString(2);
                       p4 = res.getString(3);
                       p5 = res.getString(4);
                       p6 = res.getString(5);

                       pn.setText(p2);
                       pt.setText(p5);
                       pd.setText(p6);
                       pdt.setText(p7);
                      // String url =p4;
                      // new FetchImage(url).start();
                       if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages.jpg")){
                           pi.setImageResource(R.drawable.im1);
                       }
                       else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(2).jpg")){
                           pi.setImageResource(R.drawable.im3);
                       }
                       else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                           pi.setImageResource(R.drawable.im2);
                       }
                       else if(p4.equals("content://com.android.providers.downloads.documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fimages%20(1).jpg")){
                           pi.setImageResource(R.drawable.im4);
                       }
                   }
            }
            }
        });
       /* while(res.moveToNext()){
                p1 = res.getInt(0);
                p2 = res.getString(1);
                p3 = res.getString(2);
                p4 = res.getString(3);
                p5 = res.getString(4);
                p6 = res.getString(5);}
                pn.setText(p3);
                pt.setText(p5);
                pd.setText(p6);
                //pi.setImageURI(Uri.parse(p4));
        String url =p4;
        new FetchImage(url).start();*/


    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {

                    return true;


        }
        return super.onOptionsItemSelected(item);

}




}