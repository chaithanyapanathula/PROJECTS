package com.example.miniproject;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.text.DateFormat;
import java.util.Calendar;

public class reminder extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {
    private TextView mTextView;
    private DrawerLayout drawerLayout2;
    private ActionBarDrawerToggle actionBarDrawerToggle2;

    private String phone,name,emailid,password;
    private NavigationView nav2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");
        drawerLayout2 = findViewById(R.id.my_drawer_layout2);

        nav2=(NavigationView)findViewById(R.id.nav2);
        actionBarDrawerToggle2 = new ActionBarDrawerToggle(this, drawerLayout2, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout2.addDrawerListener(actionBarDrawerToggle2);
        actionBarDrawerToggle2.syncState();

        nav2.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(reminder.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(reminder.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(reminder.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(reminder.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(reminder.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(reminder.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(reminder.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(reminder.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(reminder.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout2.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mTextView = findViewById(R.id.textView);

        Button buttonTimePicker = findViewById(R.id.button_timepicker);
        buttonTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        Button buttonCancelAlarm = findViewById(R.id.button_cancel);
        buttonCancelAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm();
            }
        });
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hourOfDay);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);

        updateTimeText(c);
        startAlarm(c);
    }

    private void updateTimeText(Calendar c) {
        String timeText = "Reminder set for: ";
        timeText += DateFormat.getTimeInstance(DateFormat.SHORT).format(c.getTime());
        Toast.makeText(getApplicationContext(),timeText,Toast.LENGTH_SHORT).show();
    }

    private void startAlarm(Calendar c) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
    }

    private void cancelAlarm() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        alarmManager.cancel(pendingIntent);

        Toast.makeText(getApplicationContext(),"Reminder Cancelled",Toast.LENGTH_SHORT).show();
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle2.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }
}