package com.example.miniproject;

import static java.time.temporal.ChronoUnit.DAYS;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.time.LocalDate;

public class DBClean extends SQLiteOpenHelper {
    public DBClean(Context context) {
        super(context, "Userclean.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Usercleandetails(phno TEXT primary key,cleandate date default CURRENT_DATE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Usercleandetails");
    }

    public void insertuserdata(String phno)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("phno", phno);
        long result=DB.insert("Usercleandetails", null, contentValues);

    }
    public void updateuserdata(String phno) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        DB.execSQL("DELETE FROM Usercleandetails WHERE phno='"+phno+"'");
        contentValues.put("phno", phno);
        long result=DB.insert("Usercleandetails", null, contentValues);
       }
       public int getcountdata (String phno)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Usercleandetails where phno = ?", new String[]{phno});
        return cursor.getCount();

    }
    public String usergetDate(String phno){
        String dt="";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Usercleandetails where phno = ?", new String[]{phno});
        if(cursor.getCount()>0){
        while(cursor.moveToNext()){
            dt="Last activity was  ";
            String dl=cursor.getString(1);

            LocalDate date = LocalDate.parse(dl);

            long diff=DAYS.between(date,LocalDate.now());
            if(diff!=0){
            dt=dt+diff+" day/days ago";}
            else{
                dt="Last activity was today";
            }

        }}
        else{
            dt="No events yet";
        }
        return dt;

    }
}
