package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.VideoView;

public class forgotpw extends AppCompatActivity {
    private VideoView videoBG;
    private View a1;
    MediaPlayer mMediaPlayer;
    int mCurrentVideoPosition;
    EditText phno,em,pswd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpw);
       Button reg = (Button) findViewById(R.id.reg3);
        a1=(View)findViewById(R.id.a1);

        phno=(EditText)findViewById(R.id.phno3);
        em=(EditText)findViewById(R.id.em3);
        pswd=(EditText)findViewById(R.id.pswd3);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLogin DB = new DBLogin(getApplicationContext());


                // below line is to get data from all edit text fields.

                String phno1 = phno.getText().toString();
                String em1 = em.getText().toString();
                String pswd1 =pswd.getText().toString();
                if (phno1.isEmpty() ||  em1.isEmpty()|| pswd1.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(pswd1.length()<5){
                    Toast.makeText(getApplicationContext(), "Password must be more than 5 characters.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                Boolean checkupdatedata = DB.updateuserdata(phno1,em1,pswd1);
                if(checkupdatedata==true){
                    Toast.makeText(getApplicationContext(), "Entry Updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(view.getContext(), nxtlogin.class);
                    view.getContext().startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "User not found", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(view.getContext(), login.class);
                    view.getContext().startActivity(intent);

                }}
            }
        });
        videoBG = (VideoView) findViewById(R.id.videoView);

        // Build your video Uri
        Uri uri = Uri.parse("android.resource://" // First start with this,
                + getPackageName() // then retrieve your package name,
                + "/" // add a slash,
                + R.raw.bkg); // and then finally add your video resource. Make sure it is stored
        // in the raw folder.

        // Set the new Uri to our VideoView
        videoBG.setVideoURI(uri);
        // Start the VideoView
        videoBG.start();

        // Set an OnPreparedListener for our VideoView. For more information about VideoViews,
        // check out the Android Docs: https://developer.android.com/reference/android/widget/VideoView.html
        videoBG.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mMediaPlayer = mediaPlayer;

                // We want our video to play over and over so we set looping to true.
                mMediaPlayer.setLooping(true);
                // We then seek to the current posistion if it has been set and play the video.
                if (mCurrentVideoPosition != 0) {
                    mMediaPlayer.seekTo(mCurrentVideoPosition);
                    mMediaPlayer.start();
                }
            }
        });
    }

    /*================================ Important Section! ================================
    We must override onPause(), onResume(), and onDestroy() to properly handle our
    VideoView.
     */

    @Override
    protected void onPause() {
        super.onPause();
        // Capture the current video position and pause the video.
        int mCurrentVideoPosition = mMediaPlayer.getCurrentPosition();
        videoBG.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restart the video when resuming the Activity
        videoBG.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // When the Activity is destroyed, release our MediaPlayer and set it to null.
        mMediaPlayer.release();
        mMediaPlayer = null;
    }
    }
