package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;

import com.google.android.material.navigation.NavigationView;

public class medicines extends AppCompatActivity {
    WebView wv3;
    private DrawerLayout drawerLayout9;
    private ActionBarDrawerToggle actionBarDrawerToggle9;

    private String phone,name,emailid,password;
    private NavigationView nav9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicines);
        wv3 = (WebView) findViewById(R.id.webv1);
        wv3.loadUrl("https://www.flipkart.com/search?q=pet+medicine&sid=p3t%2Ccez%2Cw4e&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_na&otracker1=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_na&as-pos=1&as-type=RECENT&suggestionId=pet+medicine%7CPet+First+Aid+Kit&requestId=f1fd048b-86f2-4f9d-a5ec-3926a5cbe787&as-searchtext=pet%20%20med");
        wv3.getSettings().setJavaScriptEnabled(true);

        Bundle bd = getIntent().getExtras();
        phone = bd.getString("phone");
        name = bd.getString("name");
        emailid = bd.getString("emailid");
        password = bd.getString("password");
        drawerLayout9= findViewById(R.id.my_drawer_layout9);

        nav9=(NavigationView)findViewById(R.id.nav9);
        actionBarDrawerToggle9= new ActionBarDrawerToggle(this, drawerLayout9, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout9.addDrawerListener(actionBarDrawerToggle9);
        actionBarDrawerToggle9.syncState();

        nav9.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_about:
                                intent=new Intent(medicines.this, about.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);


                                break;
                            case R.id.nav_addpost:
                                intent=new Intent(medicines.this, blogadd.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_home:
                                intent=new Intent(medicines.this, dash.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_love:
                                intent=new Intent(medicines.this,love.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_food:
                                intent=new Intent(medicines.this, reminder.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_clean:
                                intent=new Intent(medicines.this, clean.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_shop:
                                intent=new Intent(medicines.this, shop.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_faqs:
                                intent=new Intent(medicines.this, faq.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;
                            case R.id.nav_logout:
                                intent=new Intent(medicines.this,use.class);
                                intent.putExtra("phone",phone);
                                intent.putExtra("name",name);
                                intent.putExtra("emailid",emailid);
                                intent.putExtra("password",password);
                                startActivity(intent);
                                break;



                            default:
                                break;
                        }
                        // Close the navigation drawer when an item is selected.
                        menuItem.setChecked(true);
                        drawerLayout9.closeDrawers();
                        return true;
                    }
                });
        // to make the Navigation drawer icon always appear on the action bar

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle9.onOptionsItemSelected(item)) {

            return true;


        }
        return super.onOptionsItemSelected(item);

    }
}