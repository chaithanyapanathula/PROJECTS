package MyThread;
import java.sql.*;
import javax.swing.JLabel;
import miniproject.*;
public class newThread extends Menu implements Runnable{
 String name;
 Runnable m1;
 static int a,b,c;
 // boolean suspendflag=
 Thread t1=new Thread(this,"Student");
 
 Thread t2=new Thread(this,"Trainee");
 
 Thread t3=new Thread(this,"Recruiter");
  public newThread(String title)
 {super(title);
 t1.start();
 
 t2.start();
 
 t3.start();
 
 while((t3.isAlive()||t2.isAlive()||t1.isAlive())==true);
 st=new JLabel("Student :"+String.valueOf(a));
 st.setBounds(0,150,400,50);
 First.setLabel(st);
 add(st);
 tr=new JLabel("Trainees :"+String.valueOf(b));
 tr.setBounds(00,200,400,50);
 First.setLabel(tr);
 add(tr);
 rec=new JLabel("Recruiters:"+String.valueOf(c));
 rec.setBounds(0,250,400,50);
 First.setLabel(rec);
 add(rec);
 }
 @Override
 public synchronized void run() {
 
 try {
 if(Thread.currentThread().getName().equals("Student")) 
 a=sqlcount("SELECT COUNT(*) FROM STUDENT");
 
 else if(Thread.currentThread().getName().equals("Trainee"))
 b=sqlcount("SELECT COUNT(*) FROM TRAINEE");
 
 else if(Thread.currentThread().getName().equals("Recruiter"))
 c=sqlcount("SELECT COUNT(*) FROM REC");
 } catch (ClassNotFoundException | SQLException ex) { ex.printStackTrace();
 } 
 
 }
 synchronized int sqlcount(String sql) throws SQLException, ClassNotFoundException {
try {
Class.forName("com.mysql.jdbc.Driver");
Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
Statement statement = connect.createStatement();
ResultSet resultSet = statement.executeQuery(sql);
while (resultSet.next()) {
return resultSet.getInt(1);
}
} catch (ClassNotFoundException | SQLException e) {
 System.out.println(e);
 return 0;
}
return 0; 
 }
 
}