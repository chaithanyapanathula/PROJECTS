package miniproject;
import java.awt.event.ActionEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JOptionPane;
import static miniproject.Display.con;
public class Trainee extends St_Register {
static int v;
public Trainee(String title) {
 super(title);
 l[0].setText("TRAINEE REGISTRATION");
 l[1].setText("ORGANISER NAME:");
 l[2].setText("INSTITUTION:"); 
 l[3].setText("COURSE NAME:");
 l[4].setText("COURSE PERIOD:");
 l[5].setText("COURSE FEE:");
 l[6].setText("MODE(ON/OFFLINE):");
 
 
 }
 @Override
 public void actionPerformed(ActionEvent e) {
 String str=e.getActionCommand();
if("ADD".equals(str))
 { 
 Display.db(); 
 try{
 con = DriverManager .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 
 
}
catch(SQLException b) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 
try{ 
 
 
PreparedStatement ps = con.prepareStatement("INSERT INTO TRAINEE VALUES (?,?,?,?,?,?,?)");
for(int k=1;k<=7;k++)
{ if(k==1)
{ 
 st = con.createStatement();
 ResultSet rs=st.executeQuery("SELECT * FROM TRAINEE");
 ResultSetMetaData rsmt=rs.getMetaData();
 int c=rsmt.getColumnCount();
 Vector row=new Vector(c);
 
 while(rs.next())
 { row=new Vector(c);
 
 ++v;
 }
 
 idnum="TR".concat(Integer.toString(v)); 
 ps.setString(1,idnum);
 }
 else
{ps.setString(k,t[k-1].getText()); 
 
}}
 
int t = ps.executeUpdate();
 if(t>0)
 
 { JOptionPane.showMessageDialog(this,"IDnum:".concat(idnum),"Registered",1); 
 System.out.println("You are sucessfully registered");
 } 
}catch (SQLException b) {
 System.out.println(b);
 b.printStackTrace();
 return;
}
 try {
 st.close();
 con.close();
 } catch (SQLException ex) {
 System.out.println(ex); }
 this.dispose();
 new Trainee("Trainee Registration");}
 
 if("BACK".equals(str))
 {
 this.dispose();
 new Menu("Menu");
 }
 
}}