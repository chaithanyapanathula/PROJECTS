package miniproject;
import MyThread.newThread;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import static miniproject.Display.con;public class Menu extends First {
JMenuBar mb; 
JMenu m1,m11,m2,m3,m33;
JMenuItem i1a,i11a,i11b,m2a,m2b,m2c,m3a,m3b,m33a,m33b;
JButton b1;
public static JLabel l1,st,tr,rec; 
public Menu(String title){
super(title);
 
 mb=new JMenuBar();
setJMenuBar(mb);
m1=new JMenu("Student");
 mb.add(m1);
 m2=new JMenu("Trainee");
 mb.add(m2);
 m2a=new JMenuItem("Register");
 m2.add(m2a);
 m2b=new JMenuItem("List");
 m2.add(m2b);
 m2c=new JMenuItem("Delete");
 m2.add(m2c);
 m11=new JMenu("St_Details");
 m1.add(m11);
 i11a=new JMenuItem("St_Edit");
 m11.add(i11a);
 i11b=new JMenuItem("St_Display");
 m11.add(i11b);
 i1a=new JMenuItem("St_Register");
 m1.add(i1a);
 m3=new JMenu("Recruiter");
 mb.add(m3);
 m3a=new JMenuItem("REGISTER"); m3.add(m3a);
 m3b=new JMenuItem("Drives");
 m3.add(m3b);
 m33=new JMenu("Selected");
 m3.add(m33);
 m33a=new JMenuItem("Insert");
 m33.add(m33a);
 m33b=new JMenuItem("View");
 m33.add(m33b);
 i1a.addActionListener(this);
 i11a.addActionListener(this);
 i11b.addActionListener(this); 
 m2a.addActionListener(this);
 m2b.addActionListener(this); 
 m2c.addActionListener(this); 
 m33a.addActionListener(this);
 m33b.addActionListener(this);
 m3a.addActionListener(this);
 m3b.addActionListener(this); 
 b1=new JButton("CALCULATE");
 b1.setBounds(400,50,150,50);
 add(b1);
 b1.addActionListener(this);
 l1=new JLabel("CLICK TO VIEW NUMBER OF REGISTRATIONS");
 l1.setBounds(0,0,700,30);
 setButton(l1);
 add(l1);
 
}
 
 
@Override
public void actionPerformed(ActionEvent e) {
String str=e.getActionCommand();
if("St_Display".equals(str))
 
{ Display d1=new Display();
 d1.db();
 d1.dis("SELECT * FROM STUDENT");
 d1.dbclose();}
 if("St_Register".equals(str))
 { this.dispose();
 new St_Register("St_Register");
 }
 if("St_Edit".equals(str))
 { this.dispose();
 new St_Edit("St_Edit");
 }
 if("Register".equals(str))
 { this.dispose();
 new Trainee("Trainee Registration");
 }
 if("List".equals(str))
 { Display d3=new Display();
 Display.db();
 d3.dis("SELECT * FROM TRAINEE");
 d3.dbclose();
 }
 if("Register".equals(str))
 { this.dispose();
 new Trainee("Trainee Registration");
 }
 
 if("Delete".equals(str))
 { Statement st;
 String name=JOptionPane.showInputDialog(null,"Enter ID NUMBER to be deleted:");  Display d1=new Display();
 Display.db();
 try {
 con = DriverManager
 .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 System.out.println(name);
 try{
 
 System.out.println(name);
 st = con.createStatement();
 boolean t=false;
 ResultSet rs= st.executeQuery("SELECT * FROM TRAINEE WHERE TR_ID = '" + name+"'");
 if(rs.next())
 {
 t=true;
 }
 
 String query ="DELETE FROM TRAINEE WHERE TR_ID=?";
 PreparedStatement preparedStmt = con.prepareStatement(query);
 preparedStmt.setString(1,name);
 preparedStmt.execute();
 
 if(t==true)
 { Trainee.v++;
 JOptionPane.showMessageDialog(null,name, "Deleted", JOptionPane.INFORMATION_MESSAGE);
 System.out.println(name+"is deleted");
 }
 else
 {JOptionPane.showMessageDialog(null,name, "Not found", JOptionPane.INFORMATION_MESSAGE);
 }
 
 }
 catch(SQLException e3) {
 
 System.out.println(e3);
 } 
 con.close(); 
}catch (SQLException e1) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 }
 if("Drives".equals(str))
 {Display d4=new Display();
 Display.db();
 d4.dis("SELECT * FROM REC");
 d4.dbclose();
 
 } 
 if("REGISTER".equals(str))
 { this.dispose();
 new Recruiter_Reg("Recruiter Registration");
 }
 if("Insert".equals(str))
 { this.dispose();
 new Rec_Selected("Selected Insert");
 }
 if("View".equals(str))
 { Display d4=new Display();
 Display.db();
 d4.dis("SELECT * FROM SELECTED");
 d4.dbclose();
 }
 if("CALCULATE".equals(str))
 {
 this.dispose(); 
 new newThread("Menu");
 
 }
 }
}