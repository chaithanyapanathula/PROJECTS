package miniproject;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
public class St_Search extends First {
 
 Connection con;
 JRadioButton r1,r2;
 JButton r3,r4,b3;
 JComboBox b1,b2;
 St_Search(String title) {
 super(title);
 r1=new JRadioButton("Individidual Search");
 setButton(r1);
 r1.setBounds(10,100,400,100);
 r2=new JRadioButton("CGPA WISE");
 setButton(r2);
 r2.setBounds(430,100,200,100);
 String logs[]={"select","YES","NO"};
 String br[]={"Select","CSE","EEE","ISE","ECE","MEC","AUT","CIV","BCA","BBA","MCA","MBA","MTECH"};
 r3=new JButton("Backlogs");
 setButton(r3);
 r3.setBounds(10,300,300,50);
 r4=new JButton("Branchwise");
 setButton(r4);
 r4.setBounds(430,300,300,50);
 b3=new JButton("BACK");
 setButton(b3);
 b3.setBounds(500,500,200,50);
 b1= new JComboBox(logs); 
 setButton(b1);
 b1.setBounds(10,350,100,50);
 b2= new JComboBox(br);  setButton(b2);
 b2.setBounds(430,350,300,50);
 add(r1);
 add(r2);
 add(b1);
 add(b2);
 add(b3);
 add(r3);
 add(r4);
 r1.addActionListener(this);
 r2.addActionListener(this);
 r3.addActionListener(this);
 r4.addActionListener(this);
 
 b1.addActionListener(this);
 b2.addActionListener(this);
 b3.addActionListener(this);
 
 
 
 }
 @Override
 public void actionPerformed(ActionEvent e) {
 String str=e.getActionCommand();
 if("Individidual Search".equals(str))
 { String name=JOptionPane.showInputDialog(null,"Enter ID NUMBER:");
 
 Display.db();
 Display d2=new Display();
 boolean t= d2.dis("SELECT * FROM STUDENT WHERE ST_ID = '" + name+"'");
 if(t==false)
 {
 JOptionPane.showMessageDialog(null,name, "NOT FOUND!", JOptionPane.INFORMATION_MESSAGE);  }
 d2.dbclose();
 }
 if ("CGPA WISE".equals(str))
 {
 String mark=JOptionPane.showInputDialog(null,"Enter minimum CGPA:");
 int m=Integer.parseInt(mark);
 Display.db();
 Display d2=new Display();
 boolean t= d2.dis("SELECT * FROM STUDENT WHERE TOTAL_CGPA >= '" + m +"'");
 if(t==false)
 {
 JOptionPane.showMessageDialog(null,mark, "NONE!", JOptionPane.INFORMATION_MESSAGE); 
 }
 d2.dbclose();
 }
 if (b1==e.getSource())
 {
 String logs=(String) b1.getSelectedItem();
 Display.db();
 Display d2=new Display();
 boolean t= d2.dis("SELECT * FROM STUDENT WHERE BACKLOGS = '" + logs +"'");
 if(t==false)
 {
 JOptionPane.showMessageDialog(null,logs, "NONE!", JOptionPane.INFORMATION_MESSAGE); 
 }
 d2.dbclose();
 
 }
 if (b2==e.getSource())
 {
 String br=(String) b2.getSelectedItem();
 Display.db();
 Display d2=new Display(); boolean t= d2.dis("SELECT * FROM STUDENT WHERE BRANCH = '" + br +"'");
 if(t==false)
 {
 JOptionPane.showMessageDialog(null,br, "NONE!", JOptionPane.INFORMATION_MESSAGE); 
 }
 d2.dbclose();
 } 
 if("BACK".equals(str))
 {
 this.dispose();
 new Menu ("Menu");
 }
 } 
}