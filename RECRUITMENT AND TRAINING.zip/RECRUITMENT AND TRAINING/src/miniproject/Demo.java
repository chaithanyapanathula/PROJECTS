package miniproject;
public class Demo {
 public static void main(String[] args){
 new Welcome("Welcome");
 }
}
