package miniproject;
import java.awt.event.*;
import javax.swing.*;
public class Welcome extends First{
private JLabel l1,l2;
private JButton b1;
Welcome(String title){
super(title);
 
l1=new JLabel("RECRUITMENT AND TRAINING"); 
l1.setBounds(100,180,600,100);
setLabelHead(l1);
l2=new JLabel("Desktop Application");
l2.setBounds(150,250,500,100);
setLabelHead(l2);
 b1=new JButton("Start");
 b1.setBounds(200,350,110,30);
 setButton(b1);
 add(b1);
add(l1);
 add(l2); 
 b1.addActionListener(this);
 
}
public void actionPerformed(ActionEvent e) {
String s1="Start";
String str=e.getActionCommand();
if(s1.equals(str))
{ this.dispose();
 new Login("Login");
 }
}}