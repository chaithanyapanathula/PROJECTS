package miniproject;
import java.awt.BorderLayout;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
public class Display extends JFrame{
 boolean t;
 static Connection con=null;
 Statement st; 
public static void db()
{
 System.out.println("-------- MySQL JDBC Connection Demo ------------");
 
 try
 {
 Class.forName("com.mysql.jdbc.Driver");
 } 
 catch (ClassNotFoundException e) {
 System.out.println("MySQL JDBC Driver not found !!");
 
 }
}
public boolean dis(String sql)
{try { 
con = DriverManager .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!"); 
 st = con.createStatement();
 ResultSet rs= st.executeQuery(sql);
 ResultSetMetaData rsmt=rs.getMetaData();
 int c=rsmt.getColumnCount();
 Vector column=new Vector(c);
 for(int i=1;i<=c;i++)
 {
 column.add(rsmt.getColumnName(i));
 }
 Vector data=new Vector();
 Vector row=new Vector();
 if(rs.next())
 { t=true; 
 rs.beforeFirst();
 while(rs.next())
 {
 row=new Vector(c);
 for(int i=1;i<=c;i++)
 {
 row.add(rs.getString(i));
 }
 data.add(row);
 
 }
 JFrame frame=new JFrame();
 frame.setSize(500,120);
 frame.setLocationRelativeTo(null);
 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 JPanel panel = new JPanel(); 
 JTable table = new JTable(data,column);
 JScrollPane jsp = new JScrollPane(table); 
 panel.setLayout(new BorderLayout());  panel.add(jsp,BorderLayout.CENTER); 
 frame.setContentPane(panel); frame.setVisible(true);
 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);}
 else
 {
 t=false;
 }
 
}catch (SQLException e1) {
 System.out.println(e1);
 return t;
}return t;}
 public void dbclose()
 {
 try {
 st.close();
 con.close();
 } catch (SQLException ex) {
 System.err.append("Unable to close connection"+ex); }
 }}