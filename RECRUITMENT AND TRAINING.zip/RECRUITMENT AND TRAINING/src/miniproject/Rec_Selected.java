package miniproject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;
import static miniproject.Display.con;
import static miniproject.First.setLabelHead;
public class Rec_Selected extends First{
 JLabel la,lb,ld;
 JTextField ta,tc;
 private static ResultSet rs;
 String p,q,r,s,t,u;
 JButton b,b1;
 
 public Rec_Selected(String title) {
 super(title);
 setSize(750,600);
 la=new JLabel("Selected");
 setLabelHead(la);
 la.setBounds(50,50,500,40);
 lb =new JLabel("Student Id:");
 setLabel(lb);
 lb.setBounds(100,150,250,30);
 
 
 ld=new JLabel("Company name:");
 setLabel(ld);
 ld.setBounds(100,250,250,30);
 ta=new JTextField();
 ta.setBounds(350,150,250,30);
 
 
  b=new JButton("Back");
 setButton(b);
 b.setBounds(500,500,100,50);
 add(b);
 b.addActionListener(this);
 
 b1=new JButton("Add");
 setButton(b1);
 b1.setBounds(300,500,100,50);
 add(b1);
 b1.addActionListener(this);
 add(la);
 add(lb);
 add(ta);
 add(ld);
tc=new JTextField();
tc.setBounds(350,250,250,30);
add(tc);
 
 }
 @Override
 public void actionPerformed(ActionEvent e) {
 
 String str=e.getActionCommand();
 if("Back".equals(str))
 {
this.dispose();
new Menu("Menu");
 }
 if("Add".equals(str))
 { DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy"); Calendar cal = Calendar.getInstance();
 String selectedDate=dateFormat.format(cal.getTime());
 Display.db();
 try{
 con = DriverManager
 .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 
 
}
catch(SQLException b) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 
try{ 
 
 
PreparedStatement ps = con.prepareStatement("INSERT INTO SELECTED VALUES (?,?,?)");
 
 ps.setString(1, ta.getText());
ps.setString(2, selectedDate);
ps.setString(3, tc.getText());
 
int t1 = ps.executeUpdate();
 if(t1>0)
 
 { JOptionPane.showMessageDialog(this,"DONE!!","Inserted",1); 
 }
 
 Statement st = con.createStatement(); rs= st.executeQuery("SELECT * FROM STUDENT WHERE ST_ID='" + ta.getText()+"'");
ResultSetMetaData rsmt=rs.getMetaData();
rs.next();
 p=rs.getString(2);
 q=rs.getString(3); 
 r=rs.getString(4); 
 s=rs.getString(5); 
 t=rs.getString(6);
 
 
}catch (SQLException b) {
 System.out.println(b);
 b.printStackTrace();
 return;
}
 finally{
 try { 
String string =ta.getText()+"|"+p+"|"+q+"|"+r+"|"+s+"|"+t+"|"+"Selected date:("+selectedDate+")"+"\t"+tc.getText()+"\n"+"\n";
System.out.println(string);
File f1 = new File("D:\\4SEM\\Rec\\Selected.txt");
BufferedWriter out = new BufferedWriter( new FileWriter(f1, true)); 
 out.write(string); 
 out.close(); 
 System.out.println("Successfully wrote to the file.");
 
}catch(IOException ioe) {
System.out.println("Exception Caught : " +ioe);
} 
 try { 
 con.close();
 } catch (SQLException ex) {
 System.out.println(ex); } Statement st;
 String name=ta.getText();
 Display d1=new Display();
 Display.db();
 try {
 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 System.out.println(name);
 try{
 String query ="DELETE FROM STUDENT WHERE ST_ID=?";
 PreparedStatement preparedStmt = con.prepareStatement(query);
 preparedStmt.setString(1,name);
 preparedStmt.execute();
 }
 catch(SQLException e3)
{ 
 System.out.println(e3);
 } }
 catch(SQLException e16)
{ 
 System.out.println(e16);
 }
 
try{ 
 con.close(); 
}catch (SQLException e1) {
 System.out.println("Connection Failed! Check output console");
 return;
} }
 this.dispose();
 new Rec_Selected("Selected Insert");
}}}