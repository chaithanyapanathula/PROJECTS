package miniproject;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import static miniproject.Display.con;
public class St_Edit extends First {
 public St_Edit(String title) {
 super(title);
 
JButton r1=new JButton ("Delete");
 setButton(r1);
 r1.setBounds(200,100,300,100);
 add(r1);
 JButton r2=new JButton("Search");
 r2.setBounds(200,300,300,100); 
 setButton(r2);
 add(r2);
 r1.addActionListener(this); r2.addActionListener(this);
 JButton b3=new JButton("BACK");
 setButton(b3);
 b3.setBounds(450,450,200,50);
 add(b3);
 b3.addActionListener(this);
 }
 @Override
 public void actionPerformed(ActionEvent e) {
 String str=e.getActionCommand();
 if("Delete".equals(str))
 { Statement st;
 String name=JOptionPane.showInputDialog(null,"Enter ID NUMBER to be deleted:"); 
 Display d1=new Display();
 Display.db();
 try {
 con = DriverManager
 .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 System.out.println(name);
 try{
 String sql="DELETE FROM STUDENT WHERE ST_ID=".concat(name);
 System.out.println(name);
 st = con.createStatement();
 boolean t=false;
 ResultSet rs= st.executeQuery("SELECT * FROM STUDENT WHERE ST_ID = '" + name+"'");
 if(rs.next())
 {
 t=true;
 }
 
 String query ="DELETE FROM STUDENT WHERE ST_ID=?";
 PreparedStatement preparedStmt = con.prepareStatement(query);
 preparedStmt.setString(1,name);
 preparedStmt.execute();
 
 if(t==true)
 { St_Register.p++;
 JOptionPane.showMessageDialog(null,name, "Deleted", 
JOptionPane.INFORMATION_MESSAGE);
 System.out.println(name+"is deleted");
 }
 else
 {JOptionPane.showMessageDialog(null,name, "Not found", 
JOptionPane.INFORMATION_MESSAGE);
 }
 
 }
 catch(SQLException e3)
 {
  System.out.println(e3);
 } 
 con.close(); 
}catch (SQLException e1) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 }
 if("Search".equals(str))
 { this.dispose();
 new St_Search("St_Search");
 }
 if("BACK".equals(str))
 {
 this.dispose();
 new Menu("Menu");
 }
 }
 }
 
