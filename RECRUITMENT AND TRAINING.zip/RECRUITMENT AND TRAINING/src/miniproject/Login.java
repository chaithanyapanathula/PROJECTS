package miniproject;
import java.awt.event.ActionEvent;
import javax.swing.*;
public class Login extends First{
JTextField t1;
JPasswordField p1;
private JLabel l1,l2,l3;
private JButton b1,b2;
Login(String title)
{ 
super(title);
l1=new JLabel("LOGIN FORM");l1.setBounds(100,100,400,40);
setLabelHead(l1);
l2=new JLabel("USER NAME:");
l2.setBounds(100,150,300,30);
setLabel(l2);
l3=new JLabel("PASSWORD:");
l3.setBounds(100,230,300,30);
setLabel(l3);
 t1=new JTextField();
t1.setBounds(270,150,50,30);
 p1=new JPasswordField();
p1.setBounds(270,230,50,30);
p1.setEchoChar('X');
b1=new JButton("OK");
b1.setBounds(300,300,100,30);
setButton(b1);
b2=new JButton("EXIT");
b2.setBounds(450,300,100,30);
 setButton(b2);
 add(l1); 
add(l2);
add(l3);
add(t1);
add(p1);
add(b1);
add(b2);
 
t1.addActionListener(this);
p1.addActionListener(this);
 b1.addActionListener(this);
b2.addActionListener(this);
}
public void actionPerformed(ActionEvent e) {
String s1=t1.getText();
String s2=p1.getText();
String s3="OK";
String s4="EXIT";
String str=e.getActionCommand();
if(s3.equals(str))
{
if("NHCE".equals(s1) && "NHCE".equals(s2))
{
this.dispose();
new Menu("Menu");
}
else
{
t1.setText("");
p1.setText(""); 
JOptionPane.showMessageDialog(null,"Please verify the correct Login and Password","Warning",JOptionPane.OK_CANCEL_OPTION);}
}
if( str=="EXIT")
{ 
JOptionPane.showMessageDialog(null,"The project is still in progress,do u want to quit now","Warning",JOptionPane.OK_CANCEL_OPTION);
if(s4.equals(str))
 {
 System.exit(0);
 }
 repaint();
}
}
}