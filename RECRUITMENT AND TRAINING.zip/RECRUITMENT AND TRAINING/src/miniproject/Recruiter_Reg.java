package miniproject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import static miniproject.Display.con;
public class Recruiter_Reg extends First{
 JLabel la,lb,lc,ld;
 JTextField ta,tb;
 TextArea t3;
 // JScrollPane s;
Statement st;
static int g;
 JButton b,b1;
 public Recruiter_Reg(String title) {
 super(title);
 setSize(750,600);
 la=new JLabel("Recruiter Registration");
 setLabelHead(la); la.setBounds(50,50,600,40);
 lb =new JLabel("Name:");
 setLabel(lb);
 lb.setBounds(100,150,250,30);
 
 lc =new JLabel("Drive Date:");
 setLabel(lc);
 lc.setBounds(100,200,250,30);
 ld=new JLabel("About:");
 setLabel(ld);
 ld.setBounds(100,250,250,30);
 ta=new JTextField();
 ta.setBounds(350,150,250,30);
 tb=new JTextField();
 tb.setBounds(350,200,250,30);
 
 
 b=new JButton("Back");
 b.setBounds(500,500,100,50);
 setButton(b);
 add(b);
 b.addActionListener(this);
 
 b1=new JButton("Add");
 b1.setBounds(300,500,100,50);
 setButton(b1);
 
 add(b1);
 b1.addActionListener(this);
 add(la);
 add(lb);
 add(lc);
 add(ta);
 add(tb);
 add(ld);
t3=new TextArea(300,250);
t3.setBounds(350,250,300,250);
add(t3);
 
 add(t3);
 
 }
 @Override
 public void actionPerformed(ActionEvent e) {
 String str=e.getActionCommand();
 if("Back".equals(str))
 {
 new Menu("Menu");
 } if("Add".equals(str))
 { String idnum;
 Display.db();
 try{
 con = DriverManager
 .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 
 
}
catch(SQLException b) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 
try{ 
 
 
PreparedStatement ps = con.prepareStatement("INSERT INTO REC VALUES (?,?,?)");
 st = con.createStatement();
 ResultSet rs=st.executeQuery("SELECT * FROM REC");
 ResultSetMetaData rsmt=rs.getMetaData();
 int c=rsmt.getColumnCount();
 Vector row=new Vector(c);
 
 while(rs.next())
 { row=new Vector(c);
 
 ++g;
 }
 
 idnum="REC".concat(Integer.toString(g)); 
 ps.setString(1,idnum);
 ps.setString(2, ta.getText());
ps.setString(3, tb.getText());
 
int t = ps.executeUpdate();
 if(t>0)
 
 { JOptionPane.showMessageDialog(this,"IDnum:".concat(idnum),"Registered",1); 
 
 System.out.println("You are sucessfully registered");
 }
 
}catch (SQLException b) {
 System.out.println(b);
 b.printStackTrace();
 return;
}
 try { st.close();
 
 con.close();
 
 } catch (SQLException ex) {
 System.out.println(ex); }
 finally{
 try{
String s = ta.getText()+"("+tb.getText()+")"+":\t"+t3.getText()+"\n"+"\n";
System.out.println(s);
File f = new File("D:\\4SEM\\Rec\\Company.txt");
BufferedWriter out = new BufferedWriter( new FileWriter(f, true)); 
 out.write(s); 
 out.close(); 
 System.out.println("Successfully wrote to the file.");
}
catch(IOException ioe) {
System.out.println("Exception Caught : " +ioe.getMessage());
}
 }
 this.dispose();
 new Recruiter_Reg("Recruiter Registration");
 
 }
 
 }
 
}