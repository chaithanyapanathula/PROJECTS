package miniproject;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.*;
import javax.swing.*;import static miniproject.Display.con;
public class St_Register extends First{
protected JTextField t[];
String branch,idnum,id;
int j;
JLabel l[];
Statement st;
static int p;
JButton b1,b2;
static String d[];
 public St_Register(String title) {
 super(title);
 this.t = new JTextField[8];
 this.l=new JLabel[8];
 
 l[0]=new JLabel("STUDENT REGISTRATION ");
l[0].setBounds(50,0,600,40);
setLabelHead(l[0]);
l[1]=new JLabel("USN:");
 l[2]=new JLabel("NAME:");
 l[3]=new JLabel("BRANCH:");
l[4]=new JLabel("EMAIL-ID:");
 l[5]=new JLabel("Total cgpa");
 l[6]=new JLabel("BACKLOGS:");
 j=100;
 for(int k=1;k<=6;k++)
 {
 
 super.setLabel(l[k]);
 l[k].setBounds(100,j,250,30);
 t[k]=new JTextField();
 t[k].setBounds(400,j,200,30);
 j+=50;
 add(l[k]);
 add(t[k]);
 }
 
b1=new JButton("ADD");
b1.setBounds(400,500,100,30);
setButton(b1);
b2=new JButton("BACK");
b2.setBounds(550,500,150,30);
 setButton(b2);
 add(l[0]);
add(b1);
add(b2);
 
 b1.addActionListener(this);
 
 b2.addActionListener(this);
  }
 
 @Override
 public void actionPerformed(ActionEvent e) {
 String str=e.getActionCommand();
if("ADD".equals(str))
 { 
 Display.db(); 
 
 try{
 con = DriverManager
 .getConnection("jdbc:mysql://localhost:3306/miniproject", "root", "kavya");
 System.out.println("SQL Connection to database established!");
 
 
}
catch(SQLException b) {
 System.out.println("Connection Failed! Check output console");
 return;
}
 
try{ 
 
 
PreparedStatement ps = con.prepareStatement("INSERT INTO STUDENT VALUES (?,?,?,?,?,?,?)");
branch=t[3].getText();
 
for(int k=1;k<=7;k++)
{ if(k==1)
 { 
 st = con.createStatement();
 ResultSet rs=st.executeQuery("SELECT * FROM STUDENT");
 ResultSetMetaData rsmt=rs.getMetaData();
 int c=rsmt.getColumnCount();
 Vector row=new Vector(c);
 
 while(rs.next())
 { row=new Vector(c);
 
 ++p;
 }
 id="ST".concat(branch);
 idnum=id.concat(Integer.toString(p)); 
 ps.setString(1,idnum);
 
 } 
 else
{ps.setString(k,t[k-1].getText()); 
 
}} 
int t = ps.executeUpdate();
 if(t>0)
 
 { JOptionPane.showMessageDialog(this,"IDnum:".concat(idnum),"Registered",1); 
 
 }
 
}catch (SQLException b) {
 System.out.println(b);
 return;
}
 try {
 st.close();
 
 con.close();
 
 } catch (SQLException ex) {
 System.out.println(ex); }
 this.dispose();
 new St_Register("St_Register");}
 
 if("BACK".equals(str))
 {
 this.dispose();
 new Menu("Menu");
 }
 }}