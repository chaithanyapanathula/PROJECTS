package miniproject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public abstract class First extends JFrame implements ActionListener{
 String title;
 static Font fonthead,font;
 static Color c1,c2; 
 Image icon;
 First(String title){
 super(title);
 this.title=title;
 font=new Font("",Font.ROMAN_BASELINE,25);
 c1 =new Color(255,255,255);
 c2=new Color(10,10,10); 
 fonthead=new Font("",Font.BOLD,40);
icon =Toolkit.getDefaultToolkit().getImage("D:\\4SEM\\Rec\\src\\icon.png"); 
 setIconImage(icon); 
 setSize(750,600);
 setLocationRelativeTo(null);
 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 setLayout(new FlowLayout());
 setContentPane(new JLabel(new ImageIcon("D:\\4SEM\\Rec\\src\\First1.jpg")));
 setResizable(false);
 setVisible(true);
 }
static void setLabelHead(JComponent l) {
l.setFont(fonthead);
l.setForeground(c1);
}
public static void setLabel(JComponent l)
{
l.setFont(font);
l.setForeground(c1);
}
public static void setButton(JComponent l){
 l.setFont(font);
 l.setForeground(c2);
}
public abstract void actionPerformed(ActionEvent e); 
} 