<?php

include('db.php');
$reg=$_GET['reg'];
$em=$_GET['em'];
$dist=$_GET['dist'];
$bname=$_GET['bname'];

$result = mysqli_query($conn,"SELECT contact,name FROM user_reg where email LIKE '%".$em."%' ;");
while($row = $result->fetch_assoc()) {
  $contact=$row["contact"];
  $pname=$row["name"];
  
}
$sql = 'INSERT INTO request(person,shop,contact,distance,request,answer,place_order,pname,billed,paid) values("'.trim($em).'","'.trim($reg).'",'.$contact.','.$dist.',"no","no","no","'.trim($pname).'","no","no");';

$conn->query($sql);
$conn->close();


?>
