
<?php

include('db.php');
$result = mysqli_query($conn,"SELECT count FROM count_photo_reg ;");
while($row = $result->fetch_assoc()) {
  $cnt=$row["count"];
 
}

$aadhar="D:/6SEM/PHOTOSTAT/XAMPP/htdocs/photostat/aadhar/".substr(trim($_POST['copyapic']),11);
$shop="D:/6SEM/PHOTOSTAT/XAMPP/htdocs/photostat/shop/".substr(trim($_POST['copyspic']),11);
$passport="D:/6SEM/PHOTOSTAT/XAMPP/htdocs/photostat/passport/".substr(trim($_POST['copyptpic']),11);
$ext="PHREG0";
$avail="no";
$reg=$ext.$cnt;
$sql = 'INSERT INTO photo_reg 
values (
  " '. $reg.  "\",\"
                    " . trim($_POST['phname']) . "\",\"
                    " . trim($_POST['phbusserv']) . "\",
                    " . trim($_POST['phcont']). ",
                    " . trim($_POST['phaadhar']). ",\"
                    " . $aadhar. "\",\"
                    " . $passport. "\",\"
                    " . $shop. "\",
                    " . trim($_POST['lat']). ",
                    " .trim($_POST['lon']). ",\"
                    " . trim($_POST['phlocurl']). "\",\"
                    " . trim($_POST['phemail']). "\",\"
                    " . trim($_POST['copypsw']). "\",\"
                    " . trim($_POST['phbusname']). "\",'no'
                    );";
                  
                    function function_alert($message,$reg,$avail,$conn) {
                     
                      echo "<script>alert('$message');</script>";
                      echo "<script>window.location.href ='http://localhost:8080/photostat/mainpage.php';</script>";
                  }
                    
                    
                
                    
if ($conn->query($sql) === TRUE) {
 
  function_alert("Account Sucessfully Created.Make note of your registration id:".$reg,$reg,$avail,$conn);
  exit();
 
} else {
  $conn->close();
  $message="ERROR OCUURED.TRY AGAIN LATER";
  echo "<script>alert('$message');</script>";
  exit();
}

?>

