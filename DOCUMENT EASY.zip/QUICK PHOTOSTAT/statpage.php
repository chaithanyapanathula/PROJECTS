
<?php

if(!empty($_POST['insCheck'])){
  include('db.php');
  $token=trim($_POST['token']);
  $bill=trim($_POST['bill']);

  $bill="http://localhost:8080//photostat/bills/".trim($bill);
  $amt=trim($_POST['amt']);
  
  $sql="UPDATE request set billed='yes' where token=$token;";

  $conn->query($sql);
  $sql="INSERT into transaction values($token,'$bill',$amt,'no')";

  $conn->query($sql);
  
  
  $conn->close();
 
  
}
  ?>
  <html>
<head>
<link rel="stylesheet" href="http://localhost:8080/photostat/common.css">
<style>
  .collapsible {
  background-color:   Plum;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 25px;
}

.active, .collapsible:hover {
  background-color: crimson;
  color:white;
}

.collapsible:after {
  content: '\002B';
  color: white;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.content {
  padding: 0 18px;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  background-color: #f1f1f1;
}
table{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: purple;
  color: gold;
}
a.visited {
  pointer-events: none;
  cursor: default;
  color:grey;
}

</style>
</head>
<body>

<div class="topnav"height="40px">
  <a href="mainpage.php" title="Go to home page" target="_blank"><img src="homeicon.png" width="40px" height="40px"></a>
  <a href="mainpage.php" title="Go to home page" target="_self" style="float:right;"><button name="logout"  title="Log Out" style="float:right;border-color:rgb(69, 27, 90);border:5pc;border-radius:25%;padding:1px;background-color:rgb(69, 27, 90);"><img src="logout.jpg" width="40px" height="40px" ></button></a>
   <h1 style="text-align:center;color:gold;text-decoration: overline underline;padding:0px;">QUICK PHOTOSTAT</h1>
   </div>
  

  <div style="background-color:rgb(69, 27, 90);padding:20px;margin: 15px;">
  <form method="post">
  <b><h2 style='background-color:gold'>AVAILABLE:</h3></b>
  <?php

  $reg=$_GET['reg'];
  
if(isset($_POST['button1'])) {
        
         include('db.php');
         $sql = "UPDATE `photo_reg` SET `available` = 'yes' WHERE `photo_reg`.`regid` ='$reg';";      
if ($conn->query($sql) === TRUE) {
  echo "<b><h2 style='background-color:gold'>YOU ARE MARKED AVAILABLE</h3></b>";
} else {
  echo "Retry";
}
$conn->close();

      }
if(isset($_POST['button2'])) {
          
include('db.php');
$sql = "UPDATE `photo_reg` SET `available` = 'no' WHERE `photo_reg`.`regid` ='$reg';";      
 if ($conn->query($sql) === TRUE) {
  echo "<b><h2 style='background-color:gold'>YOU ARE IN BREAK PERIOD</h3></b>";
 } else {
   echo "Retry";
 }
 $conn->close();
      }
  ?>

      <input type="submit" name="button1"
              value="ON" style="background-color:green;color:white;border: none;border-radius: 100%;box-shadow: 0 9px #999; font-size: 24px;padding: 15px 25px;" >
        
      <input type="submit" name="button2" value="OFF" style="background-color:red;color:white;border: none;border-radius: 100%;box-shadow: 0 9px #999; font-size: 24px;padding: 15px 25px;" >
  </form>
    </div>
    <button class="collapsible">My information</button>
<div class="content">
<p>
<?php
include('db.php');
$reg=$_GET['reg'];


$sql="SELECT * FROM photo_reg WHERE regid LIKE '%".$reg."%'";


$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>
  <tr>
    <td>PHOTOSTAT:<?php echo htmlentities($row['businessName']) ?></td>
</tr>

<tr>
    <td>SERVICES:<?php echo htmlentities($row['services']) ?></td>
</tr>

<tr>
    <td>NAME:<?php echo htmlentities($row['name']) ?></td>
</tr>
<tr>
    <td>CONTACT NUMBER:<?php echo htmlentities($row['contact']) ?></td>
</tr>
<tr>
    <td>EMAIL ID:<?php echo htmlentities($row['email']) ?></td>
</tr>

<tr>
    <td>ADRESS LINK:<a href="<?php echo htmlentities($row['location']) ?>" target="_blank"><?php echo htmlentities($row['location']) ?></a></td>
</tr> 
</table>
<?php
    }

}






?>
</p>

</div>
<br>
<br>
<br>
<button class="collapsible">BILLING ORDERS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from request where shop like '%$reg%' and request like '%yes%' and answer like '%yes%' and place_order like '%yes%' and billed like '%no%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<form action=# method="POST" >
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>NAME</th>
    <th>CONTACT NUMBER</th>
    <th>EMAIL ID</th>
    <th>GENERATE BILL</th>
    <th>UPLOAD BILL</th>
    <th>TOTAL AMOUNT(in Rs.)</th>
    <th>SUBMIT</th>

   
  </tr>
 
  <tr>
    <td><input type="number" value=<?php echo htmlentities($row['token']) ?> id="token"  name="token"></td>
    <td><?php echo htmlentities($row['pname']) ?></td>
    <td><?php echo htmlentities($row['contact']) ?></td>
    <td><?php echo htmlentities($row['person']) ?></td>
<td><button id="mBt1" onclick="window.location.reload();"><a id="mAt1" href="http://localhost:8080/photostat/index.php?token=<?php echo $row['token'] ?>&regid=<?php echo trim($reg) ?>"  target="_self" >Bill Maker</a> </button></td>
    <td><input type="file" id="bill" name="bill"></td>
    <td><input type="text" id="amt" name="amt"></td>
    <td><input type="submit" id="insCheck" name="insCheck" onclick="window.location.reload();" value="SUBMIT"></td>
    
  </tr>
   
  
</table>
</form>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>

<button class="collapsible">REQUESTING DEALS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from request where shop like '%".$reg."%' and request like '%no%' and answer like '%no%' and place_order like '%no%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>NAME</th>
    <th>CONTACT NUMBER</th>
    <th>EMAIL ID</th>
    <th>DISTANCE</th>
    <th>CALLED</th>

   
  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
    <td><?php echo htmlentities($row['pname']) ?></td>
    <td><?php echo htmlentities($row['contact']) ?></td>
    <td><?php echo htmlentities($row['person']) ?></td>
    <td><?php echo htmlentities($row['distance']) ?></td>
    <td><button id="mBt" onclick="window.location.reload();"><a id="mAt" href="http://localhost:8080/photostat/update_request.php?token=<?php echo $row['token'] ?>"  target="b3" >Yes</a> </button></td>
    
  </tr>
   
  
</table>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">MY ORDERS</button>
<div class="content">
<p>
<?php
$reg=$_GET['reg'];
include('db.php');
$sql="SELECT * from transaction where paid like'%yes%' and token in (SELECT token from request where shop like '%".$reg."%')";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>Bill</th>
    <th>Amount(in Rs.)</th>
  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
   
    <td><a href="<?php echo htmlentities($row['bfile']) ?>" target="_blank">Click here</a></td>
    <td><?php echo htmlentities($row['amt']) ?></td>

  </tr>
   
</table>
<?php
    }

}





?>
</p>
</div>
</div>


<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>

</body>

</html>
<div id="pag">
<iframe name = "b3" src = "http://localhost:8080/photostat/fd.php" style="width:0%; height:0%"></iframe>
</div>
<script>
