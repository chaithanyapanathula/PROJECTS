<?php
$reg=$_GET['reg'];

?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://localhost:8080/photostat/common.css">

<style>
  iframe {
			width: 100%;
			height: 300px;
		}
.button {
width:50%;
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  
  cursor: pointer;
}

.collapsible {
  background-color:Plum;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 25px;
}

.active, .collapsible:hover {
    background-color: crimson;
  color:white;
}

.collapsible:after {
  content: '\002B';
  color: white;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.content {
  padding: 0 18px;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  background-color: #f1f1f1;
}
table{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: purple;
  color: gold;
}

iframe {
			width: 100%;
			height: 500px;
      background-color: transparent;
		}


</style>
</head>
<body onload=getLocation()>

<div class="topnav"height="40px">
  <a href="mainpage.php" title="Go to home page" target="_blank"><img src="homeicon.png" width="40px" height="40px"></a>
  <a href="mainpage.php" title="Go to home page" target="_self" style="float:right;"><button  title="Log Out" style="float:right;border-color:rgb(69, 27, 90);border:5pc;border-radius:25%;padding:1px;background-color:rgb(69, 27, 90);" ><img src="logout.jpg" width="40px" height="40px" ></button></a>
   <h1 style="text-align:center;color:gold;text-decoration: overline underline;padding:0px;">QUICK PHOTOSTAT</h1>
   </div>

<button class="collapsible">My information</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from user_reg where email like '%$reg%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <td>NAME:<?php echo htmlentities($row['name']) ?></td>
    <td>CONTACT:<?php echo htmlentities($row['contact']) ?></td>
    <td>EMAIL ID:<?php echo htmlentities($row['email']) ?></td>
    
    

  </tr>
   
   
</table>
<?php
    }

}

$conn->close();



?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">HISTORY PAYMENTS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from transaction where paid like'%yes%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>Bill</th>
    <th>Amount(in Rs.)</th>
  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
   
    <td><a href="<?php echo htmlentities($row['bfile']) ?>" target="_blank">Click here</a></td>
    <td><?php echo htmlentities($row['amt']) ?></td>

  </tr>
   
</table>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">BILLED ORDERS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from transaction where paid like '%no%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>Bill</th>
    <th>Amount(in Rs.)</th>
    <th>Make Payment</th>

  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
    <?php $st=$row['bfile']?>
   
    <td><a href=<?php echo htmlentities($row['bfile'])?> target="_blank">CLICK HERE</a></td>
    <td><?php echo htmlentities($row['amt']) ?></td>
    <td><button id="Bt21" onclick="window.location.reload();"><a id="mAt2" href="http://localhost:8080/photostat/paid.php?token=<?php echo htmlentities($row['token']) ?>"  target="bl" onclick="window.location.reload();">Proceed To Pay</a></button></td>
    

  </tr>
   
   
</table>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">WAITING ORDERS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from request where person like '%$reg%' and request like '%yes%' and answer like '%yes%' and place_order like '%yes%' and billed like '%no%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>NAME</th>
  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
    <td><?php echo htmlentities($row['shop']) ?></td>
    

  </tr>
   
</table>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">CONFIRMATION DEALS</button>
<div class="content">
<p>
<?php

include('db.php');
$sql="SELECT * from request where person like '%".$reg."%' and request like '%yes%' and answer like '%yes%' and place_order like '%no%'";

$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>
<table>

  <tr>
    <th>TOKEN NUMBER</th>
    <th>NAME</th>
    
    <th>DISTANCE</th>
    <th>CONFIRM</th>
    <th>CANCEL</th>
   

   
  </tr>
 
  <tr>
    <td><?php echo htmlentities($row['token']) ?></td>
    <td><?php echo htmlentities($row['shop']) ?></td>

    <td><?php echo htmlentities($row['distance']) ?></td>
    <td><button id="Bt1" onclick="window.location.reload();"><a id="mAt1" href="http://localhost:8080/photostat/confirm_request.php?token=<?php echo htmlentities($row['token']) ?>"  target="bl" onclick="window.location.reload();">Confirm Order</a> </button></td>
    <td><button id="Bt2" onclick="window.location.reload();"><a id="mAt2" href="http://localhost:8080/photostat/cancel_order.php?token=<?php echo htmlentities($row['token']) ?>"  target="bl" onclick="window.location.reload();">Cancel Order</a></button></td>
    
  </tr>
   
  
</table>
<?php
    }

}





?>
</p>
</div>
<br>
<br>
<br>
<button class="collapsible">Find Nearest Photostat services</button>
<div class="content">
<script type="text/javascript">

    function getLocation(){
        if(navigator.geolocation){
            navigator.geolocation.getCurrentPosition(showPosition)
        }
    }
    function showPosition(position){
        document.getElementById("lats").value=position.coords.latitude;
        document.getElementById("longs").value=position.coords.longitude;
    
    }

</script>
<form action=# method="POST">
<input type="text" name="lats" id="lats">
<input type="text" name="longs" id="longs">
<button class="button" type="submit" name="subm" id="subm">Find Nearest</button>
</form>
<?php
if(isset($_POST['subm'])){
    $v1=$_POST['lats'];
    $v2=$_POST['longs'];
   
    include('db.php');
//$v1=doubleval($_GET['lat']);
//$v2=doubleval($_GET['long']);

$sql="SELECT *,(3959 * acos(cos(radians ($v1)) *cos(radians(lattitude))*cos(radians(longtitude)-radians($v2))+sin(radians($v1))*sin(radians(lattitude)))) AS distance FROM photo_reg WHERE available='yes' having distance<=10 order by distance";


$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>


<table>
  <tr>
    <th>Shop</th>
    <th>Distance(in km)</th>
  </tr>
  <tr>
    <td><?php echo htmlentities($row['businessName']) ?></td>
    <td><?php echo htmlentities($row['distance']) ?></td> 
    <td><a href="http://localhost:8080/photostat/userpage.php?reg=<?php echo htmlentities($row['regid']) ?>&em=<?php echo $reg ?>&dist=<?php echo htmlentities($row['distance']) ?>&bname=<?php echo htmlentities($row['businessName']) ?>" target="main"> View more</a></td>
  </tr>

	
  <table>


<?php
    
    }
}
}
?>
</div>
<br>
<br>
<br>


<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<div id="pag">
<iframe name = "main" src = "http://localhost:8080/photostat/fd.php"></iframe>
</div>
<div id="pag">
<iframe name = "bl" src = "http://localhost:8080/photostat/fd.php" style="width:0%; height:0%"></iframe>
</div>





</body>
</html>
