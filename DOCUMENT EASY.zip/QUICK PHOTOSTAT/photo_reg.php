<!DOCTYPE html>
<html>
<head>
<title>Photostat registration</title>
<link rel="stylesheet" href="http://localhost:8080/photostat/common.css">
<style>
  .collapsible {
  background-color: #777;
  color: white;
  cursor: pointer;
  padding: 18px;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
}
.active, .collapsible:hover {
  background-color: #555;
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #f1f1f1;
}

.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  padding:2px;
 
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;

  color: black;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color:beige;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: black;
  background-color:beige;
  font-weight: bolder;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
  </style>

</head>


<body>

<div class="topnav"height="40px">
  <a href="mainpage.php" title="Go to home page"><img src="homeicon.png" width="40px" height="40px"></a>
   <h1 style="text-align:center;color:gold;text-decoration: overline underline;padding:0px;">QUICK PHOTOSTAT</h1>
   </div>
<div style="background-color:rgb(69, 27, 90);padding:20px;margin: 15px;">
  <h1 style="color:white;text-align:center;">Photostat Registration</h1>
  <form method="POST" action="insert_photo_reg.php" enctype="multipart/form-data">
  <table class="center" style="font-size:20px;color:white;">
    <tr>
      <td>
      Name:
    </td>
    <td>
      <input id="phname" name="phname" type="text" maxlength="50" style="font-size:20px;border:5px;" required>
    </td>
    </tr>
    <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
    <tr>
      <td>
    Business name:
  </td>
  <td>
  <input id="phbusname" name="phbusname" type="text" maxlength="50" style="font-size:20px;border:5px;" required>
  </td>

    </tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><br>
    <tr>
     <td> Services:</td>
     <td> <input id="phbusserv" name="phbusserv" type="text" maxlength="100" style="font-size:20px;border:5px;" required></td>
    </tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
    <td>Contact number:</td>
    <td><input id="phcont" name="phcont" type="tel" pattern="[0-9]{10}"
       maxlength="20" style="font-size:20px;border:5px;"  required><small>(format:1234567890)</small></td>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>Aadhar Number:</td><td><input id="phaadhar" name="phaadhar" type="text" pattern="[0-9]{12}"
       maxlength="20" style="font-size:20px;border:5px;"  required></td></tr>
       <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
       <tr><td>Upload Aadhar card image:</td><td><input id="phaadharpic" type="file"  name="aadharpic" accept="image/*" onchange="setapic()" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copyapic" name="copyapic" value=" "></td></tr>
       </tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
      </tr><tr><td>Your image :</td><td><br><input id="phpasspt" type="file"  name="phpasspt" accept="image/*" onchange="setptpic()" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copyptpic" name="copyptpic" value=" ">
      </td></tr>
      </tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
      </tr><tr><td>Brochure:</td><td><input id="phshoppic" type="file"  name="phshoppic" accept="image/*" onchange="setspic()" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copyspic" name="copyspic" value=" "></td></tr>
      </tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
      <script>
        function setapic(){
          document.getElementById("copyapic").value=document.getElementById("phaadharpic").value;

        }
        function setptpic(){
          document.getElementById("copyptpic").value=document.getElementById("phpasspt").value;

        }
        function setspic(){
          document.getElementById("copyspic").value=document.getElementById("phshoppic").value;

        }
      </script>
 </tr><tr><td>Location:</td>
      <td>
  
<button onclick="getLocation()">Get Location</button>
<br>

<p style="color:white;">Latitude:<input type="text" name="lat" id="demo1" style="color:gold;" value=" "></p>
<p style="color:white";>Longitude:<input type="text" name="lon" id="demo2" style="color:gold;" value=" "></p>


<script>
var x = document.getElementById("demo");
var y= document.getElementById("demo1");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
 // x.innerHTML = "Latitude: " + position.coords.latitude + 
  //"<br>Longitude: " + position.coords.longitude;
  document.getElementById("demo1").value=position.coords.latitude;
  document.getElementById("demo2").value=position.coords.longitude;

}
</script>
</td></tr>   
<tr>
  <td>
    Location Url:
  </td>
  <td>
  <input id="phlocurl" name="phlocurl" type="url" maxlength="50" style="font-size:20px;border:5px;"  required>
  <button class="collapsible" style="background-color:gold;border-radius:100%" >&#x2753;</button>
  
  <div class="content" style="width:700px;height:550px">
  <div class="slideshow-container" >

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="maphelp.png" style="width:100%">
  <div class="text" style="color:red;background-color:beige;font-size:30px;">Go to<a href="https://www.google.com/maps" target="_blank"> Google maps</a></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="maphelp2.png" style="width:100%">
  <div class="text" style="color:red;font-size:30px;background-color:beige">Search your Location</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="maphelp3.png" style="width:100%">
  <div class="text" style="color:red;font-size:30px;background-color:beige">Paste the location url in the blank above </div>
</div>

<a class="prev" onclick="plusSlides(-1)" >&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

  </div>
 <script>
var coll = document.getElementsByClassName("collapsible");
var i;
for (i = 0; i < coll.length; i++) {
coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }});}
 </script>


  </td>
</tr>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>Email id:
</td>
<td><input id="phemail" name="phemail" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
       maxlength="40" style="font-size:20px;border:5px;"  required><small>(format:name@gmail.com)</small></td>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</tr><tr><td>Password:</td><td><input name="phpassword" id="phpassword" type="password" onkeyup='check();' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" maxlength="50" style="font-size:20px;border:5px;" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copypsw" name="copypsw" value=" ">
<br><small>(Must contain 8 or more characters that are of at least one number, and one uppercase and lowercase letter)</small></td></tr>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</tr><tr><td>Confirm Password:</td><td>
<input type="password" name="confirm_password" id="confirm_password"  onkeyup='check();' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" maxlength="50" style="font-size:20px;border:5px;" required>
<span id='message'></span>
</td></tr>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<script>
  var check = function() {
    document.getElementById('copypsw').value=document.getElementById('phpassword').value;
  if (document.getElementById('phpassword').value ==
    document.getElementById('confirm_password').value) {
    
    document.getElementById('message').innerHTML = '&#9989;';
    document.getElementById("myBtn").disabled = false;
  } else {
   
    document.getElementById('message').innerHTML = '&#10060;';
    document.getElementById("myBtn").disabled = true;
    
  }
}</script>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>

<td><input type="submit" id="myBtn" VALUE="SUBMIT" style="font-size:30px;background-color:gold;"></td>
<td><input type="reset" VALUE="RESET" style="font-size:30px;background-color:gold;"></td></tr>


  </table>
</form>
</div>
</body>
</html>

 