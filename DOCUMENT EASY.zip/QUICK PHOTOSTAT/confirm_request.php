<?php

include('db.php');
$token=trim($_GET['token']);
$sql="UPDATE request set place_order='yes' where token=$token ;";

echo $conn->query($sql);
$conn->close();
?>