<?php

include('db.php');
$token=trim($_GET['token']);
$sql="delete from request where token=$token";

echo $conn->query($sql);
$conn->close();
?>