<?php
include('db.php');
$v1=doubleval($_GET['lat']);
$v2=doubleval($_GET['long']);

$sql="SELECT regid,businessName,(3959 * acos(cos(radians ($v1)) *cos(radians(lattitude))*cos(radians(longtitude)-radians($v2))+sin(radians($v1))*sin(radians(lattitude)))) AS distance FROM photo_reg WHERE available='yes' HAVING distance<=5 order by distance";


$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>

<html>
<head>
<style>
table{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: purple;
  color: gold;
}
</style>
</head>
<body>

<table>
  <tr>
    <th>Company</th>
    <th>km</th>
   
  </tr>
  <tr>
    <td><?php echo htmlentities($row['businessName']) ?></td>
    <td><?php echo htmlentities($row['distance']) ?></td>
    
  </tr>
 
  
</table>

</body>
</html>


<?php
    }

}





?>
