
<?php
include('db.php');
$reg=$_GET['reg'];
$em=$_GET['em'];
$dist=$_GET['dist'];
$bname=$_GET['bname'];

$sql="SELECT * FROM photo_reg WHERE regid LIKE '%".$reg."%'";


$result = $conn->query($sql);

if (!empty($result->num_rows) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
?>

<html>
<head>
<style>
table{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 2px solid black;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: purple;
  color: gold;
}
</style>
</head>
<body style="background-color:plum;">

<table>
  <tr>
    <td>PHOTOSTAT:<?php echo htmlentities($row['businessName']) ?></td>
</tr>

<tr>
    <td><img src="http://localhost:8080/photostat/shop/shop1.jpg" width="400px" height="400px"><br>SERVICES:<?php echo htmlentities($row['services']) ?></td>
</tr>

<tr>
    <td><img src="http://localhost:8080/photostat/passport/pp1.jpg" width="150px" height="150px"><br>NAME:<?php echo htmlentities($row['name']) ?></td>
</tr>
<tr>
    <td>CONTACT NUMBER:<?php echo htmlentities($row['contact']) ?></td>
</tr>
<tr>
    <td>EMAIL ID:<?php echo htmlentities($row['email']) ?></td>
</tr>


<tr>
    <td>ADRESS LINK:<a href="<?php echo htmlentities($row['location']) ?>" target="_blank"><?php echo htmlentities($row['location']) ?></a></td>
</tr> 
<tr>
<td>DISTANCE FROM you:<?php echo $dist ?> km</td>
</tr>


<tr> 

<td><button><a href="http://localhost:8080/photostat/insert_request.php?reg=<?php echo $_GET['reg'] ?>&em=<?php echo $_GET['em'] ?>&dist=<?php echo $_GET['dist'] ?>&bname=<?php echo htmlentities($row['businessName']) ?>" target="bl">Request for deal</a></button></td>
</tr>
</table>


</body>
</html>


<?php
    }

}






?>
