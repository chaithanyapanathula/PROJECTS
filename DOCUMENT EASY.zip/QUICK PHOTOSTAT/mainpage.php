<?php
if(!empty($_POST['photocheck'])){
 $servername = "127.0.0.1:3307";
 $us = "root";
 $psw = "";
 $dbname = "webproject";

 $connect=mysqli_connect($servername, $us, $psw, $dbname) or die("Connection Failed");

     $username=trim($_POST['regidlog']);
     $password=trim($_POST['copypsw']);
     $query="select * from photo_reg where regid LIKE '%".$username."%' and pswd LIKE '%".$password."%';";
    
     $result=mysqli_query($connect,$query);
     $count=mysqli_num_rows($result);
     if($count>0){
      header("Location:statpage.php?reg=$username");
     }
     else{
      echo "<script>ermsg()</script>";
     }
    }?>
<?php
if(!empty($_POST['usercheck'])){
 $servername = "127.0.0.1:3307";
 $us = "root";
 $psw = "";
 $dbname = "webproject";

 $connect=mysqli_connect($servername, $us, $psw, $dbname) or die("Connection Failed");

     $username=trim($_POST['regidlog1']);
     $password=trim($_POST['copypsw1']);
     $query="select * from user_reg where email LIKE '%".$username."%' and pswd LIKE '%".$password."%';";
    
     $result=mysqli_query($connect,$query);
     $count=mysqli_num_rows($result);
     if($count>0){
      header("Location:viewpage.php?reg=$username");
     }
     else{
      echo "<script>ermsg2()</script>";
     }
    }?>
<html>
<head>
<title> QUICK PHOTOSTAT</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://localhost:8080/photostat/common.css">
<link rel="stylesheet" href="http://localhost:8080/photostat/chat.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
  table{text-align:center;

  }

</style>
</head>
<body>

 
  <script>

  document.getElementById('photologin').style.display = 'none';
    document.getElementById('userlogin').style.display = 'none';
   </script>
   <script>
  function userlog(){
    if ( document.getElementById('userlogin').style.display == 'none') {
      document.getElementById('photologin').style.display = 'none';
    document.getElementById('userlogin').style.display = 'block';
  }
  else {
    
    document.getElementById('userlogin').style.display = 'none';
  }
  document.getElementById('wrongstat').innerHTML ='';
 
  }
  </script>
  <script>
   function photolog(){
    if ( document.getElementById('photologin').style.display == 'none') {
      document.getElementById('userlogin').style.display = 'none';
    document.getElementById('photologin').style.display = 'block';
  }
  else {
    
    document.getElementById('photologin').style.display = 'none';
  }
  document.getElementById('wrongstat').innerHTML ='';
  }</script>
<div class="topnav">
    <a href="#" title="Go to home page"><img src="homeicon.png" width="40px" height="40px"></a>
    <a href="http://localhost:8080/photostat/photo_reg.php"  title="Register" style="float:left;border-color:rgb(69, 27, 90);border:5pc;border-radius:25%;padding:7px;background-color:rgb(69, 27, 90);"><img src="register.png" width="40px" height="40px" ></a>
   
    <button title="Photostat login" style="float:right;border-color:rgb(69, 27, 90);border:5pc;border-radius:25%;padding:7px;background-color:rgb(69, 27, 90);" onclick="photolog()"><img src="staticon.png" width="40px" height="40px" ></a>&nbsp;&nbsp;&nbsp;
    <button  title="User Login" style="float:right;border-color:rgb(69, 27, 90);border:5pc;border-radius:25%;padding:7px;background-color:rgb(69, 27, 90);" onclick="userlog()"><img src="login.jpg" width="40px" height="40px" ></button>
   
   </div>
   <div class="headpt">
       <span class="imgam"><img src="weblogo.png" width="80px" height="80px" style="border-radius:10px;float:left;"></span><i>Q</i>UICK <i>P</i>HOTOSTAT</p>
</div>
<div style="position:relative;left:200px;top:5px;height:500px;width:700px;background-color:grey;border:2px solid grey">
  <img class="mySlides" src="slide1.jpg" style="width:100%;height:100%;padding:5px;">
  <img class="mySlides" src="slide2.jpg" style="width:100%;height:100%;padding:5px;">
  <img class="mySlides" src="slide3.jpg" style="width:100%;height:100%;padding:5px;">
</div>
<script>
  var myIndex = 0;
  slideshow();
  
  function slideshow() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(slideshow, 4000); 
  }
  </script>
   <div id="userlogin" style="display:none;position:relative;left:1000px;top:-495px;height:500px;width:500px;background-color:rgb(69, 27, 90);color:white;border:2px solid grey">
  <form id="f2" name="f2" method = "POST" action="#">
   
  <h1><center><u>USER LOGIN</u></center></h1>
    <div id="wrongstat" name="wrongstat" style="color:gold;font-size:15px;"> &nbsp;</div>
    <table class="center" style="font-size:20px;">
      <br>
      <br>
      <tr>
       <td><label>Email id:</label></td>
       <td><input id="regidlog1" name="regidlog1" type="text" maxlength="30" style="font-size:20px;" required></td>
      </tr>
      <tr>
        <td></td>
        <td><label id="sfmail1" name="sfmail1" style="color:gold;font-size:15px;">your registered email id</label></td>
      </tr>
      
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      
      <tr><td>Password:</td><td><input name="phpassword1" id="phpassword1" type="password" onkeyup='check();'  maxlength="50" style="font-size:20px;" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copypsw1" name="copypsw1" value=" ">
</td></tr>
<script>
  var check = function() {
    document.getElementById('copypsw1').value=document.getElementById('phpassword1').value;
  };</script>
      <tr>
        <td>&nbsp;</td>
        <td><label id="spwd1" name="spwd1" style="color:gold;font-size:15px;">Enter your password</label></td>
      </tr> 
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>

      <tr>
      <td><input type="submit" id="usercheck" name="usercheck"  VALUE="SUBMIT" style="font-size:20px;background-color:gold;"></td>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" VALUE="RESET" style="font-size:20px;background-color:gold;"></td></tr></tr>
    </table>
    <br>
    <br>
  <hr>
  <center><a href="http://localhost:8080/photostat/user_reg.php" style="background-color:gold;font-size:20px;text-align:center;">New User Sign UP</a> </center><br>
  

</form>
</div>
<div id="photologin" style="display:none;position:relative;left:1000px;top:-495px;height:500px;width:500px;background-color:rgb(69, 27, 90);color:white;border:2px solid grey">

<form id="f1" name="f1" method = "POST" action="#">
     <h1><center><u>PHOTOSTAT LOGIN</u></center></h1>
    <div id="wrongstat" name="wrongstat" style="color:gold;font-size:15px;"> &nbsp;</div>
    <table class="center" style="font-size:20px;">
      <br>
      <br>
      <tr>
       <td><label>Registration Id:</label></td>
       <td><input id="regidlog" name="regidlog" type="text" maxlength="30" style="font-size:20px;" required></td>
      </tr>
      <tr>
        <td></td>
        <td><label id="sfmail" style="color:gold;font-size:15px;">your registration id</label></td>
      </tr>
      
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      
      <tr><td>Password:</td><td><input name="phpassword" id="phpassword" type="password" onkeyup='check();'  maxlength="50" style="font-size:20px;" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copypsw" name="copypsw" value=" ">
</td></tr>
<script>
  var check = function() {
    document.getElementById('copypsw').value=document.getElementById('phpassword').value;
  };</script>
      <tr>
        <td>&nbsp;</td>
        <td><label id="spwd" style="color:gold;font-size:15px;">Enter your password</label></td>
      </tr> 
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>

      <tr>
      <td><input type="submit" id="photocheck" name="photocheck"  VALUE="SUBMIT" style="font-size:20px;background-color:gold;"></td>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" VALUE="RESET" style="font-size:20px;background-color:gold;"></td></tr></tr>
    </table>
    <br>
    <br>
  <hr>
  <center><a href="http://localhost:8080/photostat/photo_reg.php" style="background-color:gold;font-size:20px;text-align:center;">New User Sign UP</a> </center><br>
  

</form>
  </div>
  <script>
  function ermsg(){
 
  document.getElementById('photologin').style.display = 'block';
  alert('WRONG CREDENTIALS');
  document.getElementById('f1').reset();}
  function ermsg2(){
 
 document.getElementById('photologin').style.display = 'block';
 alert('WRONG CREDENTIALS');
 document.getElementById('f2').reset();}
  </script> 
 
        

</body>

</html>

