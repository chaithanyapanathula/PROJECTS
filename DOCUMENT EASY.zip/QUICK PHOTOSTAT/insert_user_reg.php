
<?php

$servername = "127.0.0.1:3307";
$username = "root";
$password = "";
$dbname = "webproject";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$passport="D:/6SEM/PHOTOSTAT/XAMPP/htdocs/photostat/userimg/".substr(trim($_POST['copyptpic']),11);

$sql = 'INSERT INTO user_reg 
values (" '. trim($_POST['phemail']).  "\"," . trim($_POST['phcont']). ",\"" . $passport. "\",\"" . trim($_POST['phname']). "\",\"
                    " . trim($_POST['copypsw']). "\");";
echo $sql;
                  
                    function function_alert($message) {
                     
                      echo "<script>alert('$message');</script>";
                      echo "<script>window.location.href ='http://localhost:8080/photostat/mainpage.php';</script>";
                  }
                    
                    
                
                    
if ($conn->query($sql) === TRUE) {
    $conn->close();
  function_alert("Account Sucessfully Created.Sign in");
  exit();
 
} else {
  $conn->close();
  $message="ERROR OCUURED.TRY AGAIN LATER";
  echo "<script>alert('$message');</script>";
  exit();
}

?>

