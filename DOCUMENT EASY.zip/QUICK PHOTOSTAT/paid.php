<?php
include('db.php');
$token=trim($_GET['token']);
$bill=trim($_GET['bill']);
$bill="D:/6SEM/PHOTOSTAT/XAMPP/htdocs/photostat/bills/".substr(trim($_POST['copyapic']),11);
$amt=trim($_GET['amt']);

$sql="UPDATE request set paid='yes' where token=$token;";
$conn->query($sql);
$sql="UPDATE transaction set paid='yes' where token=$token;";
$conn->query($sql);

$conn->close();
?>