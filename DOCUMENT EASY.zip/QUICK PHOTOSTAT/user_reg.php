<!DOCTYPE html>
<html>
<head>
<title>Photostat registration</title>
<link rel="stylesheet" href="http://localhost:8080/photostat/common.css">
<style>
 </style>

</head>


<body>

<div class="topnav"height="40px">
  <a href="mainpage.php" title="Go to home page"><img src="homeicon.png" width="40px" height="40px"></a>
   <h1 style="text-align:center;color:gold;text-decoration: overline underline;padding:0px;">QUICK PHOTOSTAT</h1>
   </div>
<div style="background-color:rgb(69, 27, 90);padding:20px;margin: 15px;">
  <h1 style="color:white;text-align:center;">USER SIGN UP</h1>
  <form method="POST" action="insert_user_reg.php" enctype="multipart/form-data">
  <table class="center" style="font-size:20px;color:white;">
    <tr>
      <td>
      Name:
    </td>
    <td>
      <input id="phname" name="phname" type="text" maxlength="50" style="font-size:20px;border:5px;" required>
    </td>
    </tr>
    <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
    <td>Contact number:</td>
    <td><input id="phcont" name="phcont" type="tel" pattern="[0-9]{10}"
       maxlength="20" style="font-size:20px;border:5px;"  required><small>(format:1234567890)</small></td>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>Your image :</td><td><br><input id="phpasspt" type="file"  name="phpasspt" accept="image/*" onchange="setptpic()" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copyptpic" name="copyptpic" value=" ">
      </td></tr>
      
      <script>
        function setptpic(){
          document.getElementById("copyptpic").value=document.getElementById("phpasspt").value;

        }
      
      </script>
 </tr>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>Email id:
</td>
<td><input id="phemail" name="phemail" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
       maxlength="40" style="font-size:20px;border:5px;"  required><small>(format:name@gmail.com)</small></td>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</tr><tr><td>Password:</td><td><input name="phpassword" id="phpassword" type="password" onkeyup='check();' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" maxlength="50" style="font-size:20px;border:5px;" required><input type="text" style="color:rgb(69, 27, 90);background-color:rgb(69, 27, 90);border:none;" id="copypsw" name="copypsw" value=" ">
<br><small>(Must contain 8 or more characters that are of at least one number, and one uppercase and lowercase letter)</small></td></tr>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</tr><tr><td>Confirm Password:</td><td>
<input type="password" name="confirm_password" id="confirm_password"  onkeyup='check();' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" maxlength="50" style="font-size:20px;border:5px;" required>
<span id='message'></span>
</td></tr>
</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<script>
  var check = function() {
    document.getElementById('copypsw').value=document.getElementById('phpassword').value;
  if (document.getElementById('phpassword').value ==
    document.getElementById('confirm_password').value) {
    
    document.getElementById('message').innerHTML = '&#9989;';
    document.getElementById("myBtn").disabled = false;
  } else {
   
    document.getElementById('message').innerHTML = '&#10060;';
    document.getElementById("myBtn").disabled = true;
    
  }
}</script>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>

<td><input type="submit" id="myBtn" VALUE="SUBMIT" style="font-size:30px;background-color:gold;"></td>
<td><input type="reset" VALUE="RESET" style="font-size:30px;background-color:gold;"></td></tr>


  </table>
</form>
</div>
</body>
</html>