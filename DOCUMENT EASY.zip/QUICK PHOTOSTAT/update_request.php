<?php

include('db.php');
$token=trim($_GET['token']);
$sql="UPDATE request set request='yes',answer='yes' where token=$token ;";
$conn->query($sql);
$conn->close();
?>